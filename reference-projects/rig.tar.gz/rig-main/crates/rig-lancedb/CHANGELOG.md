# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [0.4.6](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.4.5...rig-lancedb-v0.4.6) - 2026-05-13

### Other

- AGENTS.MD, CONTRIBUTING.MD, and docs ([#1714](https://github.com/0xPlaygrounds/rig/pull/1714)) (by @gold-silver-copper) - #1714
- improve project organization and create rig crate ([#1699](https://github.com/0xPlaygrounds/rig/pull/1699)) (by @gold-silver-copper) - #1699

### Contributors

* @gold-silver-copper
## [0.4.5](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.4.4...rig-lancedb-v0.4.5) - 2026-04-28

### Added

- rustls by default for everything ([#1682](https://github.com/0xPlaygrounds/rig/pull/1682)) (by @gold-silver-copper) - #1682

### Other

- Add clippy no panic lints ([#1663](https://github.com/0xPlaygrounds/rig/pull/1663)) (by @gold-silver-copper) - #1663
- standardize required fields handling across builders ([#1611](https://github.com/0xPlaygrounds/rig/pull/1611)) (by @isSerge) - #1611

### Contributors

* @gold-silver-copper
* @isSerge
## [0.4.4](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.4.3...rig-lancedb-v0.4.4) - 2026-04-12

### Other

- updated the following local packages: rig-core

## [0.4.3](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.4.2...rig-lancedb-v0.4.3) - 2026-03-29

### Other

- enable specifying native-tls instead of default rustls ([#1558](https://github.com/0xPlaygrounds/rig/pull/1558))

## [0.4.2](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.4.1...rig-lancedb-v0.4.2) - 2026-03-17

### Other

- updated the following local packages: rig-core


## [0.4.1](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.4.0...rig-lancedb-v0.4.1) - 2026-03-05

### Other

- updated the following local packages: rig-core

## [0.3.0](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.33...rig-lancedb-v0.3.0) - 2026-02-17

### Added

- [**breaking**] upgrade reqwest to 0.13 with rustls as default TLS backend ([#1218](https://github.com/0xPlaygrounds/rig/pull/1218))

## [0.2.33](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.32...rig-lancedb-v0.2.33) - 2026-02-03

### Other

- updated the following local packages: rig-core

## [0.2.32](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.31...rig-lancedb-v0.2.32) - 2026-01-20

### Added

- improve vector store documentation and filter ergonomics (breaking) ([#1258](https://github.com/0xPlaygrounds/rig/pull/1258))

## [0.2.31](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.30...rig-lancedb-v0.2.31) - 2026-01-06

### Other

- updated the following local packages: rig-core

## [0.2.30](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.29...rig-lancedb-v0.2.30) - 2025-12-15

### Other

- *(rig-1090)* crate re-org ([#1145](https://github.com/0xPlaygrounds/rig/pull/1145))

## [0.2.29](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.28...rig-lancedb-v0.2.29) - 2025-12-04

### Other

- updated the following local packages: rig-core

## [0.2.28](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.27...rig-lancedb-v0.2.28) - 2025-12-01

### Added

- *(rig-985)* Consolidate provider clients ([#1050](https://github.com/0xPlaygrounds/rig/pull/1050))

### Fixed

- *(rig-1050)* Inconsistent model/agent initialisation methods ([#1069](https://github.com/0xPlaygrounds/rig/pull/1069))

## [0.2.27](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.26...rig-lancedb-v0.2.27) - 2025-11-10

### Added

- *(rig-1014)* add backend specific vector search filters ([#1032](https://github.com/0xPlaygrounds/rig/pull/1032))

### Fixed

- implement Serialize for LanceDBFilter to enable LanceDbVectorIndex usage in dynamic_context ([#1010](https://github.com/0xPlaygrounds/rig/pull/1010))

## [0.2.26](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.25...rig-lancedb-v0.2.26) - 2025-10-28

### Other

- updated the following local packages: rig-core

## [0.2.25](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.24...rig-lancedb-v0.2.25) - 2025-10-27

### Added

- *(rig-976)* support filters for `VectorSearchRequest` ([#952](https://github.com/0xPlaygrounds/rig/pull/952))
- *(rig-996)* generic streaming ([#955](https://github.com/0xPlaygrounds/rig/pull/955))

### Fixed

- *(rig-1006)* text-embedding-ada-002 doesn't support custom dimensions ([#967](https://github.com/0xPlaygrounds/rig/pull/967))

## [0.2.24](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.23...rig-lancedb-v0.2.24) - 2025-10-14

### Added

- *(rig-990)* allow configuring optional lancedb features ([#923](https://github.com/0xPlaygrounds/rig/pull/923))
- *(rig-951)* generic HTTP client ([#875](https://github.com/0xPlaygrounds/rig/pull/875))

### Fixed

- trying to fix test regressions part 2 ([#913](https://github.com/0xPlaygrounds/rig/pull/913))
- test regression ([#912](https://github.com/0xPlaygrounds/rig/pull/912))

## [0.2.23](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.22...rig-lancedb-v0.2.23) - 2025-09-29

### Other

- updated the following local packages: rig-core

## [0.2.22](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.21...rig-lancedb-v0.2.22) - 2025-09-15

### Other

- updated the following local packages: rig-core

## [0.2.21](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.20...rig-lancedb-v0.2.21) - 2025-09-02

### Other

- *(rig-907)* use where clause for trait bounds ([#749](https://github.com/0xPlaygrounds/rig/pull/749))

## [0.2.20](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.19...rig-lancedb-v0.2.20) - 2025-08-20

### Other

- updated the following local packages: rig-core

## [0.2.19](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.18...rig-lancedb-v0.2.19) - 2025-08-19

### Other

- updated the following local packages: rig-core

## [0.2.18](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.17...rig-lancedb-v0.2.18) - 2025-08-19

### Other

- updated the following local packages: rig-core

## [0.2.17](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.16...rig-lancedb-v0.2.17) - 2025-08-05

### Other

- updated the following local packages: rig-core

## [0.2.16](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.15...rig-lancedb-v0.2.16) - 2025-08-05

### Added

- *(rig-845)* cosine similarity for vector search ([#664](https://github.com/0xPlaygrounds/rig/pull/664))

## [0.2.15](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.14...rig-lancedb-v0.2.15) - 2025-07-30

### Added

- *(rig-819)* vector store index request struct ([#623](https://github.com/0xPlaygrounds/rig/pull/623))

### Other

- Refactor clients with builder pattern ([#615](https://github.com/0xPlaygrounds/rig/pull/615))

## [0.2.14](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.13...rig-lancedb-v0.2.14) - 2025-07-16

### Other

- updated the following local packages: rig-core

## [0.2.13](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.12...rig-lancedb-v0.2.13) - 2025-07-14

### Other

- updated the following local packages: rig-core

## [0.2.12](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.11...rig-lancedb-v0.2.12) - 2025-07-07

### Other

- Migrate all crates to Rust 2024 ([#539](https://github.com/0xPlaygrounds/rig/pull/539))
- Declare shared dependencies in workspace ([#538](https://github.com/0xPlaygrounds/rig/pull/538))
- Bump lancedb ([#537](https://github.com/0xPlaygrounds/rig/pull/537))
- Make clippy happy on all targets ([#542](https://github.com/0xPlaygrounds/rig/pull/542))

## [0.2.11](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.10...rig-lancedb-v0.2.11) - 2025-06-09

### Other

- Introduce Client Traits and Testing ([#440](https://github.com/0xPlaygrounds/rig/pull/440))

## [0.2.10](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.9...rig-lancedb-v0.2.10) - 2025-04-29

### Other

- updated the following local packages: rig-core

## [0.2.9](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.8...rig-lancedb-v0.2.9) - 2025-04-12

### Other

- *(lancedb)* docs, make examples idempotent ([#387](https://github.com/0xPlaygrounds/rig/pull/387))

## [0.2.8](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.7...rig-lancedb-v0.2.8) - 2025-03-31

### Other

- added mcp_tool + Example ([#335](https://github.com/0xPlaygrounds/rig/pull/335))

## [0.2.7](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.6...rig-lancedb-v0.2.7) - 2025-03-17

### Other

- updated the following local packages: rig-core

## [0.2.6](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.5...rig-lancedb-v0.2.6) - 2025-03-03

### Other

- updated the following local packages: rig-core

## [0.2.5](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.4...rig-lancedb-v0.2.5) - 2025-02-17

### Other

- updated the following local packages: rig-core

## [0.2.4](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.3...rig-lancedb-v0.2.4) - 2025-02-10

### Other

- updated the following local packages: rig-core

## [0.2.3](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.2...rig-lancedb-v0.2.3) - 2025-01-27

### Other

- update Cargo.lock dependencies

## [0.2.2](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.1...rig-lancedb-v0.2.2) - 2025-01-13

### Other

- Mock provider API in vector store integration tests (#186)

## [0.2.1](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.2.0...rig-lancedb-v0.2.1) - 2024-12-19

### Other

- *(integration-tests)* LanceDB (#136)

## [0.2.0](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.1.2...rig-lancedb-v0.2.0) - 2024-12-03

### Added

- embeddings API overhaul ([#120](https://github.com/0xPlaygrounds/rig/pull/120))

### Fixed

- *(rig-lancedb)* rag embedding filtering ([#104](https://github.com/0xPlaygrounds/rig/pull/104))

## [0.1.2](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.1.1...rig-lancedb-v0.1.2) - 2024-11-13

### Other

- update Cargo.lock dependencies

## [0.1.1](https://github.com/0xPlaygrounds/rig/compare/rig-lancedb-v0.1.0...rig-lancedb-v0.1.1) - 2024-11-07

### Fixed

- wrong reference to companion crate
- missing qdrant readme reference

### Other

- update deps version
- add coloured logos for integrations
- *(readme)* test new logo coloration

## [0.1.0](https://github.com/0xPlaygrounds/rig/releases/tag/rig-lancedb-v0.1.0) - 2024-10-24

### Added

- update examples to use new version of VectorStoreIndex trait
- replace document embeddings with serde json value
- merge all arrow columns into JSON document in deserializer
- finish implementing deserialiser for record batch
- implement deserialization for any recordbatch returned from lanceDB
- add indexes and tables for simple search
- create enum for embedding models
- add vector_search_s3_ann example
- implement ANN search example
- start implementing top_n_from_query for trait VectorStoreIndex
- implement get_document method of VectorStore trait
- implement search by id for VectorStore trait
- implement add_documents on VectorStore trait
- start implementing VectorStore trait for lancedb

### Fixed

- update lancedb examples test data
- make PR changes Pt II
- make PR changes pt I
- *(lancedb)* replace VectorStoreIndexDyn with VectorStoreIndex in examples
- mongodb vector search - use num_candidates from search params
- fix bug in deserializing type run end
- make PR requested changes
- reduce opanai generated content in ANN examples

### Other

- cargo fmt
- lance db examples
- add example docstring
- add doc strings
- update rig core version on lancedb crate, remove implementation of VectorStore trait
- remove print statement
- use constants instead of enum for model names
- remove associated type on VectorStoreIndex trait
- cargo fmt
- conversions from arrow types to primitive types
- Add doc strings to utility methods
- add doc string to mongodb search params struct
- Merge branch 'main' into feat(vector-store)/lancedb
- create wrapper for vec<DocumentEmbeddings> for from/tryfrom traits
