# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [0.5.6](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.5.5...rig-neo4j-v0.5.6) - 2026-05-13

### Other

- fix "a ancient" grammar in glarb-glarb sample text ([#1755](https://github.com/0xPlaygrounds/rig/pull/1755)) (by @abhicris) - #1755
- AGENTS.MD, CONTRIBUTING.MD, and docs ([#1714](https://github.com/0xPlaygrounds/rig/pull/1714)) (by @gold-silver-copper) - #1714
- improve project organization and create rig crate ([#1699](https://github.com/0xPlaygrounds/rig/pull/1699)) (by @gold-silver-copper) - #1699

### Contributors

* @abhicris
* @gold-silver-copper
## [0.5.5](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.5.4...rig-neo4j-v0.5.5) - 2026-04-28

### Other

- Add clippy no panic lints ([#1663](https://github.com/0xPlaygrounds/rig/pull/1663)) (by @gold-silver-copper) - #1663
- standardize required fields handling across builders ([#1611](https://github.com/0xPlaygrounds/rig/pull/1611)) (by @isSerge) - #1611

### Contributors

* @gold-silver-copper
* @isSerge
## [0.5.4](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.5.3...rig-neo4j-v0.5.4) - 2026-04-12

### Other

- updated the following local packages: rig-core

## [0.5.3](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.5.2...rig-neo4j-v0.5.3) - 2026-03-29

### Other

- updated the following local packages: rig-core

## [0.5.2](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.5.1...rig-neo4j-v0.5.2) - 2026-03-17

### Fixed

- *(gemini)* correct ProviderBuilder impl for GeminiInteractionsBuilder ([#1482](https://github.com/0xPlaygrounds/rig/pull/1482))


## [0.5.1](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.5.0...rig-neo4j-v0.5.1) - 2026-03-05

### Other

- updated the following local packages: rig-core

## [0.4.9](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.4.8...rig-neo4j-v0.4.9) - 2026-02-17

### Other

- updated the following local packages: rig-core

## [0.4.8](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.4.7...rig-neo4j-v0.4.8) - 2026-02-03

### Other

- update Cargo.toml dependencies

## [0.4.7](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.4.6...rig-neo4j-v0.4.7) - 2026-01-20

### Added

- improve vector store documentation and filter ergonomics (breaking) ([#1258](https://github.com/0xPlaygrounds/rig/pull/1258))
- make integration filters available to be used as rig agent rag store ([#1249](https://github.com/0xPlaygrounds/rig/pull/1249))

## [0.4.6](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.4.5...rig-neo4j-v0.4.6) - 2026-01-06

### Other

- updated the following local packages: rig-core

## [0.4.5](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.4.4...rig-neo4j-v0.4.5) - 2025-12-15

### Other

- *(rig-1090)* crate re-org ([#1145](https://github.com/0xPlaygrounds/rig/pull/1145))

## [0.4.4](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.4.3...rig-neo4j-v0.4.4) - 2025-12-04

### Other

- updated the following local packages: rig-core

## [0.4.3](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.4.2...rig-neo4j-v0.4.3) - 2025-12-01

### Added

- *(rig-985)* Consolidate provider clients ([#1050](https://github.com/0xPlaygrounds/rig/pull/1050))

### Fixed

- *(rig-1050)* Inconsistent model/agent initialisation methods ([#1069](https://github.com/0xPlaygrounds/rig/pull/1069))

## [0.4.2](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.4.1...rig-neo4j-v0.4.2) - 2025-11-10

### Added

- *(rig-1014)* add backend specific vector search filters ([#1032](https://github.com/0xPlaygrounds/rig/pull/1032))

## [0.4.1](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.4.0...rig-neo4j-v0.4.1) - 2025-10-28

### Other

- updated the following local packages: rig-core

## [0.4.0](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.3.8...rig-neo4j-v0.4.0) - 2025-10-27

### Added

- *(rig-976)* support filters for `VectorSearchRequest` ([#952](https://github.com/0xPlaygrounds/rig/pull/952))

### Fixed

- *(rig-1006)* text-embedding-ada-002 doesn't support custom dimensions ([#967](https://github.com/0xPlaygrounds/rig/pull/967))

### Other

- Dependent packages no longer force unnecessary features on rig-core ([#964](https://github.com/0xPlaygrounds/rig/pull/964))

## [0.3.8](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.3.7...rig-neo4j-v0.3.8) - 2025-10-14

### Added

- *(rig-951)* generic HTTP client ([#875](https://github.com/0xPlaygrounds/rig/pull/875))

### Fixed

- trying to fix test regressions part 2 ([#913](https://github.com/0xPlaygrounds/rig/pull/913))
- test regression ([#912](https://github.com/0xPlaygrounds/rig/pull/912))

## [0.3.7](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.3.6...rig-neo4j-v0.3.7) - 2025-09-29

### Other

- updated the following local packages: rig-core

## [0.3.6](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.3.5...rig-neo4j-v0.3.6) - 2025-09-15

### Other

- updated the following local packages: rig-core

## [0.3.5](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.3.4...rig-neo4j-v0.3.5) - 2025-09-02

### Other

- *(rig-907)* use where clause for trait bounds ([#749](https://github.com/0xPlaygrounds/rig/pull/749))

## [0.3.4](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.3.3...rig-neo4j-v0.3.4) - 2025-08-20

### Other

- updated the following local packages: rig-core

## [0.3.3](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.3.2...rig-neo4j-v0.3.3) - 2025-08-19

### Other

- updated the following local packages: rig-core

## [0.3.2](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.3.1...rig-neo4j-v0.3.2) - 2025-08-19

### Other

- updated the following local packages: rig-core

## [0.3.1](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.3.0...rig-neo4j-v0.3.1) - 2025-08-05

### Other

- updated the following local packages: rig-core

## [0.3.0](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.15...rig-neo4j-v0.3.0) - 2025-08-05

### Added

- *(rig-845)* cosine similarity for vector search ([#664](https://github.com/0xPlaygrounds/rig/pull/664))

## [0.2.15](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.14...rig-neo4j-v0.2.15) - 2025-07-30

### Added

- *(rig-819)* vector store index request struct ([#623](https://github.com/0xPlaygrounds/rig/pull/623))

### Other

- Refactor clients with builder pattern ([#615](https://github.com/0xPlaygrounds/rig/pull/615))

## [0.2.14](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.13...rig-neo4j-v0.2.14) - 2025-07-16

### Other

- updated the following local packages: rig-core

## [0.2.13](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.12...rig-neo4j-v0.2.13) - 2025-07-14

### Other

- updated the following local packages: rig-core

## [0.2.12](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.11...rig-neo4j-v0.2.12) - 2025-07-07

### Other

- Migrate all crates to Rust 2024 ([#539](https://github.com/0xPlaygrounds/rig/pull/539))
- Declare shared dependencies in workspace ([#538](https://github.com/0xPlaygrounds/rig/pull/538))
- Make clippy happy on all targets ([#542](https://github.com/0xPlaygrounds/rig/pull/542))

## [0.2.11](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.10...rig-neo4j-v0.2.11) - 2025-06-09

### Other

- Update lib.rs ([#497](https://github.com/0xPlaygrounds/rig/pull/497))
- Introduce Client Traits and Testing ([#440](https://github.com/0xPlaygrounds/rig/pull/440))

## [0.2.10](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.9...rig-neo4j-v0.2.10) - 2025-04-29

### Fixed

- update broken link  ([#429](https://github.com/0xPlaygrounds/rig/pull/429))

## [0.2.9](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.8...rig-neo4j-v0.2.9) - 2025-04-12

### Other

- Fix Clippy warnings for doc indentation and Error::other usage ([#364](https://github.com/0xPlaygrounds/rig/pull/364))

## [0.2.8](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.7...rig-neo4j-v0.2.8) - 2025-03-31

### Other

- updated the following local packages: rig-core

## [0.2.7](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.6...rig-neo4j-v0.2.7) - 2025-03-17

### Other

- updated the following local packages: rig-core

## [0.2.6](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.5...rig-neo4j-v0.2.6) - 2025-03-03

### Other

- updated the following local packages: rig-core

## [0.2.5](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.4...rig-neo4j-v0.2.5) - 2025-02-17

### Other

- updated the following local packages: rig-core

## [0.2.4](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.3...rig-neo4j-v0.2.4) - 2025-02-10

### Other

- updated the following local packages: rig-core

## [0.2.3](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.2...rig-neo4j-v0.2.3) - 2025-01-27

### Other

- Fix typos (#233)

## [0.2.2](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.1...rig-neo4j-v0.2.2) - 2025-01-13

### Other

- *(rig-neo4j)* remove old tests (#197)
- *(rig-neo4j)* Fix neo4j integration test (#190)
- Mock provider API in vector store integration tests (#186)
- fix typo

## [0.2.1](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.2.0...rig-neo4j-v0.2.1) - 2024-12-19

### Other

- update Cargo.lock dependencies

## [0.2.0](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.1.2...rig-neo4j-v0.2.0) - 2024-12-03

### Added

- embeddings API overhaul ([#120](https://github.com/0xPlaygrounds/rig/pull/120))

### Fixed

- *(neo4j)* remove embeddings from top_n lookup ([#118](https://github.com/0xPlaygrounds/rig/pull/118))

### Other

- *(integration test)* Neo4J ([#133](https://github.com/0xPlaygrounds/rig/pull/133))

## [0.1.2](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.1.1...rig-neo4j-v0.1.2) - 2024-11-13

### Other

- updated the following local packages: rig-core

## [0.1.1](https://github.com/0xPlaygrounds/rig/compare/rig-neo4j-v0.1.0...rig-neo4j-v0.1.1) - 2024-11-07

### Fixed

- *(neo4j)* last minute doc and const adjustments

## [0.1.0](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.0.7...rig-mongodb-v0.1.0) - 2024-10-22

### Features

- initial implementation
- supports `top_n` search for an existing index and database
