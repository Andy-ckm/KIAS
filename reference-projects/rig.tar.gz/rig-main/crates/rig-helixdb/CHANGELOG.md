# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [0.2.6](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.2.5...rig-helixdb-v0.2.6) - 2026-05-13

### Other

- AGENTS.MD, CONTRIBUTING.MD, and docs ([#1714](https://github.com/0xPlaygrounds/rig/pull/1714)) (by @gold-silver-copper) - #1714
- improve project organization and create rig crate ([#1699](https://github.com/0xPlaygrounds/rig/pull/1699)) (by @gold-silver-copper) - #1699

### Contributors

* @gold-silver-copper
## [0.2.5](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.2.4...rig-helixdb-v0.2.5) - 2026-04-28

### Added

- rustls by default for everything ([#1682](https://github.com/0xPlaygrounds/rig/pull/1682)) (by @gold-silver-copper) - #1682

### Other

- Add clippy no panic lints ([#1663](https://github.com/0xPlaygrounds/rig/pull/1663)) (by @gold-silver-copper) - #1663
- standardize required fields handling across builders ([#1611](https://github.com/0xPlaygrounds/rig/pull/1611)) (by @isSerge) - #1611

### Contributors

* @gold-silver-copper
* @isSerge
## [0.2.4](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.2.3...rig-helixdb-v0.2.4) - 2026-04-12

### Other

- updated the following local packages: rig-core

## [0.2.3](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.2.2...rig-helixdb-v0.2.3) - 2026-03-29

### Other

- updated the following local packages: rig-core

## [0.2.2](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.2.1...rig-helixdb-v0.2.2) - 2026-03-17

### Other

- updated the following local packages: rig-core


## [0.2.1](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.2.0...rig-helixdb-v0.2.1) - 2026-03-05

### Other

- updated the following local packages: rig-core

## [0.1.11](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.10...rig-helixdb-v0.1.11) - 2026-02-17

### Other

- updated the following local packages: rig-core

## [0.1.10](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.9...rig-helixdb-v0.1.10) - 2026-02-03

### Other

- updated the following local packages: rig-core

## [0.1.9](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.8...rig-helixdb-v0.1.9) - 2026-01-20

### Other

- updated the following local packages: rig-core

## [0.1.8](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.7...rig-helixdb-v0.1.8) - 2026-01-06

### Other

- updated the following local packages: rig-core

## [0.1.7](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.6...rig-helixdb-v0.1.7) - 2025-12-15

### Other

- *(rig-1090)* crate re-org ([#1145](https://github.com/0xPlaygrounds/rig/pull/1145))

## [0.1.6](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.5...rig-helixdb-v0.1.6) - 2025-12-04

### Other

- updated the following local packages: rig-core

## [0.1.5](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.4...rig-helixdb-v0.1.5) - 2025-12-01

### Added

- *(rig-985)* Consolidate provider clients ([#1050](https://github.com/0xPlaygrounds/rig/pull/1050))

### Fixed

- *(rig-1050)* Inconsistent model/agent initialisation methods ([#1069](https://github.com/0xPlaygrounds/rig/pull/1069))

## [0.1.4](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.3...rig-helixdb-v0.1.4) - 2025-11-10

### Other

- updated the following local packages: rig-core

## [0.1.3](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.2...rig-helixdb-v0.1.3) - 2025-10-28

### Other

- updated the following local packages: rig-core

## [0.1.2](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.1...rig-helixdb-v0.1.2) - 2025-10-27

### Added

- *(rig-976)* support filters for `VectorSearchRequest` ([#952](https://github.com/0xPlaygrounds/rig/pull/952))
- *(rig-996)* generic streaming ([#955](https://github.com/0xPlaygrounds/rig/pull/955))

### Other

- Dependent packages no longer force unnecessary features on rig-core ([#964](https://github.com/0xPlaygrounds/rig/pull/964))

## [0.1.1](https://github.com/0xPlaygrounds/rig/compare/rig-helixdb-v0.1.0...rig-helixdb-v0.1.1) - 2025-10-14

### Fixed

- *(rig-980)* cosine similarity threshold should work (helixdb) ([#899](https://github.com/0xPlaygrounds/rig/pull/899))
