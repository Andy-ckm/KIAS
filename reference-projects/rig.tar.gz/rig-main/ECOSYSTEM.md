This file is intended to showcase some of the activity within the Rig ecosystem.

Interested in having your project added here? Feel free to open an issue or PR.

## Community-maintained companion crates
- [graph-flow](https://github.com/a-agmon/rs-graph-llm) - a graph execution library like LangGraph that uses Rig

## Project showcase
- [clipbud](https://github.com/evilsocket/clipbud) - a cross platform util that interacts with your system clipboard and augments it with AI capabilities.
- [Litho (deepwiki-rs)](https://github.com/sopaco/deepwiki-rs) - an AI-powered documentation engine that builds out your docs using your codebase.
- [git-iris](https://github.com/hyperb1iss/git-iris) - an AI-powered tool to help automate Git workflows
- [VT Code](https://github.com/vinhnx/vtcode) - a (currently research-preview) terminal coding agent
- [Con](https://github.com/nowledge-co/con) - a GPU-accelerated terminal emulator with a built-in AI agent harness powered by Rig
- [rv](https://github.com/gi-dellav/rv) - a non-invasive AI code review tool
- [Cortex Memory](https://github.com/sopaco/cortex-mem) - The production-ready memory system for intelligent agents. A complete solution for memory management, from extraction and vector search to automated optimization, with a REST API, MCP, CLI, and insights dashboard out-of-the-box.
- [ChatShell](https://github.com/chatshellapp/chatshell-desktop) - an open-source agentic desktop AI client built on rig-core and Tauri 2. 9 built-in tools (web search, bash, file ops, grep), 40+ AI providers, MCP integration, and a composable skills system — all zero-config out of the box.
- [nitpicker](https://github.com/arsenyinfo/nitpicker) - CLI tool for multi-reviewer code review using parallel rig-core agents and an actor/critic debate loop

## Tutorials
Nothing here yet. Maybe you'd like to be the first person to add something here?

## Rig in the wild
- [Rust and Rig: Building for Stability in a Rapidly Changing AI Landscape](https://www.youtube.com/watch?v=nLlY2nNgBgM) - a talk by Joshua Mo (previous lead Rig maintainer)
- [Is Rig better than Langchain?](https://www.youtube.com/watch?v=nLlY2nNgBgM) - a video by Francesco Ciulla on Rig (and talking about Rust vs Python)
- [Building the Rig AI Framework with Rust](https://www.youtube.com/watch?v=nLlY2nNgBgM) - a podcast episode by Coding Chats on Rig
- [Rust Crate of the Year, IMO](https://www.youtube.com/watch?v=9L9oOmqD6zc&pp=ygUQY29kZSB0byB0aGUgbW9vbg%3D%3D) - a video by Code to the Moon introducing Rig and its core features

## Companies using Rig publicly
- [HelixDB](https://www.helix-db.com/) - Using Rig as part of a new internal project as well as using Rust internally, extensively
- [Coral Protocol](https://www.coralprotocol.ai/) - Using Rig for their Rust SDK as well as some other things internally
- [St Jude](https://www.stjude.org/) - Using Rig as part of a chatbot tool for [proteinpaint](https://github.com/stjude/proteinpaint), their genomics visualisation tool
- [Neon](https://neon.com/) - using Rig for [their V2 of app.build](https://github.com/neondatabase/appdotbuild-agent)
- [Syncable](https://syncable.dev/) - using Rig for their CLI
- [Refresh Agent](https://refreshagent.com/) - an AI agent heavily using Rig for SEO/marketing analysis. [Relevant article](https://refreshagent.com/engineering/building-ai-agents-in-rust)
- [nitpik](https://nitpik.dev/) - AI code reviews. Uses Rig under the hood.
