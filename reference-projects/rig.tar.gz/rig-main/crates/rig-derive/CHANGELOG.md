# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [0.1.14](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.13...rig-derive-v0.1.14) - 2026-05-13

### Other

- improve project organization and create rig crate ([#1699](https://github.com/0xPlaygrounds/rig/pull/1699)) (by @gold-silver-copper) - #1699

### Contributors

* @gold-silver-copper
## [0.1.13](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.12...rig-derive-v0.1.13) - 2026-04-28

### Added

- *(rig-derive)* support custom tool names ([#1619](https://github.com/0xPlaygrounds/rig/pull/1619)) ([#1620](https://github.com/0xPlaygrounds/rig/pull/1620)) (by @qaqland)

### Other

- Add clippy no panic lints ([#1663](https://github.com/0xPlaygrounds/rig/pull/1663)) (by @gold-silver-copper) - #1663

### Contributors

* @gold-silver-copper
* @qaqland

## [0.1.12](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.11...rig-derive-v0.1.12) - 2026-03-29

### Fixed

- *(rig-derive)* propagate function visibility to generated tool structs ([#1570](https://github.com/0xPlaygrounds/rig/pull/1570))


## [0.1.11](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.10...rig-derive-v0.1.11) - 2026-03-05

### Other

- update Cargo.toml dependencies

## [0.1.10](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.9...rig-derive-v0.1.10) - 2025-12-15

### Other

- *(rig-1090)* crate re-org ([#1145](https://github.com/0xPlaygrounds/rig/pull/1145))

## [0.1.9](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.8...rig-derive-v0.1.9) - 2025-12-01

### Added

- *(rig-985)* Consolidate provider clients ([#1050](https://github.com/0xPlaygrounds/rig/pull/1050))

### Fixed

- *(rig-1050)* Inconsistent model/agent initialisation methods ([#1069](https://github.com/0xPlaygrounds/rig/pull/1069))

## [0.1.8](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.7...rig-derive-v0.1.8) - 2025-11-10

### Fixed

- *(rig-1027)* allow any error type to be used for rig tool macro ([#1017](https://github.com/0xPlaygrounds/rig/pull/1017))

## [0.1.7](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.6...rig-derive-v0.1.7) - 2025-10-27

### Added

- *(rig-996)* generic streaming ([#955](https://github.com/0xPlaygrounds/rig/pull/955))

## [0.1.6](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.5...rig-derive-v0.1.6) - 2025-09-02

### Other

- *(rig-913)* add feature gated items to docs ([#764](https://github.com/0xPlaygrounds/rig/pull/764))

## [0.1.5](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.4...rig-derive-v0.1.5) - 2025-08-19

### Other

- *(rig-862)* remove sync bound from fn call() in tool trait ([#678](https://github.com/0xPlaygrounds/rig/pull/678))

## [0.1.4](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.3...rig-derive-v0.1.4) - 2025-07-07

### Added

- *(rig-780)* integrate openAI responses API ([#508](https://github.com/0xPlaygrounds/rig/pull/508))

### Other

- Migrate all crates to Rust 2024 ([#539](https://github.com/0xPlaygrounds/rig/pull/539))
- Declare shared dependencies in workspace ([#538](https://github.com/0xPlaygrounds/rig/pull/538))
- Make clippy happy on all targets ([#542](https://github.com/0xPlaygrounds/rig/pull/542))

## [0.1.3](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.2...rig-derive-v0.1.3) - 2025-06-09

### Other

- Introduce Client Traits and Testing ([#440](https://github.com/0xPlaygrounds/rig/pull/440))

## [0.1.2](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.1...rig-derive-v0.1.2) - 2025-04-29

### Fixed

- rig tool macro struct not public ([#409](https://github.com/0xPlaygrounds/rig/pull/409))

## [0.1.1](https://github.com/0xPlaygrounds/rig/compare/rig-derive-v0.1.0...rig-derive-v0.1.1) - 2025-04-12

### Added

- Add `rig_tool` macro ([#353](https://github.com/0xPlaygrounds/rig/pull/353))
