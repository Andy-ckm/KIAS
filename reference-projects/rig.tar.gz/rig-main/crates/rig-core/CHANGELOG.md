# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [0.37.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.36.0...rig-core-v0.37.0) - 2026-05-13

### Added

- *(openrouter)* add transcription (STT) and audio generation (TTS) support ([#1757](https://github.com/0xPlaygrounds/rig/pull/1757)) (by @fversaci)
- *(memory)* add Compactor trait, CompactingMemory adapter, and TemplateCompactor ([#1748](https://github.com/0xPlaygrounds/rig/pull/1748)) (by @ForeverAngry)
- *(ollama)* Enhance `think` parameter with string levels ([#1747](https://github.com/0xPlaygrounds/rig/pull/1747)) (by @cobaltburn)
- *(memory)* Rig-managed conversation memory + rig-memory companion crate ([#1702](https://github.com/0xPlaygrounds/rig/pull/1702)) (by @ForeverAngry)
- add copilot model listing ([#1700](https://github.com/0xPlaygrounds/rig/pull/1700)) (by @BigtoC) - #1700

### Fixed

- *(gemini)* Token usage correctness for posthog llm analytics ([#1761](https://github.com/0xPlaygrounds/rig/pull/1761)) (by @mateobelanger)
- *(openrouter)* skip serializing empty content in Assistant messages ([#1735](https://github.com/0xPlaygrounds/rig/pull/1735)) (by @pablof7z)
- *(openai)* send PDF Documents as file parts in chat completions ([#1732](https://github.com/0xPlaygrounds/rig/pull/1732)) (by @fangkangmi)
- *(core)* [**breaking**] make Chat append messages to caller history ([#1733](https://github.com/0xPlaygrounds/rig/pull/1733)) (by @gold-silver-copper)
- added a trailing newline after streamed agent response. The AgentImpl::request method streams tokens using print! macro with no trailing newline, so when the stream ends, the run loop prints the closing separator immediately which causes it to appear on the same line as the last response token - So added a println!() to the None arm of the streaming loop so a newline is always emitted after the final chunk which matches the ChatImpl path that uses println. ([#1712](https://github.com/0xPlaygrounds/rig/pull/1712)) (by @Shaurya-Sethi) - #1712
- *(mistral)* expose cached and audio token fields in Usage ([#1725](https://github.com/0xPlaygrounds/rig/pull/1725)) (by @byQuexo)

### Other

- Clean up root facade features and integration docs ([#1764](https://github.com/0xPlaygrounds/rig/pull/1764)) (by @gold-silver-copper) - #1764
- Improve GenAI token usage telemetry for Gemini and Responses API ([#1762](https://github.com/0xPlaygrounds/rig/pull/1762)) (by @gold-silver-copper) - #1762
- Memory adapter cancellation safety and trait-object forwarding ([#1756](https://github.com/0xPlaygrounds/rig/pull/1756)) (by @gold-silver-copper) - #1756
- Add demotion hooks for bounded conversation memory ([#1737](https://github.com/0xPlaygrounds/rig/pull/1737)) (by @ForeverAngry) - #1737
- Move reusable test doubles into rig_core::test_utils ([#1745](https://github.com/0xPlaygrounds/rig/pull/1745)) (by @gold-silver-copper) - #1745
- workspace and docs cleanup ([#1742](https://github.com/0xPlaygrounds/rig/pull/1742)) (by @gold-silver-copper) - #1742
- openrouter vars ([#1741](https://github.com/0xPlaygrounds/rig/pull/1741)) (by @gold-silver-copper) - #1741
- Add provider file ID support for document inputs ([#1740](https://github.com/0xPlaygrounds/rig/pull/1740)) (by @gold-silver-copper) - #1740
- bump dependencies ([#1728](https://github.com/0xPlaygrounds/rig/pull/1728)) (by @gold-silver-copper) - #1728
- Add a support of structured output for OpenRouter ([#1718](https://github.com/0xPlaygrounds/rig/pull/1718)) (by @Mnwa) - #1718
- set doctest to true, and update doc comments ([#1716](https://github.com/0xPlaygrounds/rig/pull/1716)) (by @gold-silver-copper) - #1716
- AGENTS.MD, CONTRIBUTING.MD, and docs ([#1714](https://github.com/0xPlaygrounds/rig/pull/1714)) (by @gold-silver-copper) - #1714
- improve project organization and create rig crate ([#1699](https://github.com/0xPlaygrounds/rig/pull/1699)) (by @gold-silver-copper) - #1699

### Contributors

* @gold-silver-copper
* @fversaci
* @mateobelanger
* @ForeverAngry
* @cobaltburn
* @pablof7z
* @fangkangmi
* @BigtoC
* @Shaurya-Sethi
* @Mnwa
* @byQuexo

### Added

- `rig::memory::Compactor` trait. A `Compactor` produces a single
  `Message`-shaped `Artifact` from a slice of messages a memory policy
  has evicted, optionally combining it with the previous summary
  (`carry_over`) for rolling-summary semantics. Where `DemotionHook`
  is a one-way drain that observes evicted messages, `Compactor` is
  the inverse: it returns an artifact that the composing adapter
  splices back into the active history, so the loaded prompt shape is
  `[summary, ...recent_window]` instead of a verbatim suffix. The
  trait lives in `rig_core` so any memory backend can implement it
  without taking a `rig-memory` dependency; the composing
  `CompactingMemory` adapter and a zero-dependency `TemplateCompactor`
  reference implementation live in `rig-memory`. Implementations with
  durable side effects (LLM calls, vector-store writes) must
  deduplicate per the same idempotency contract as `DemotionHook`,
  since per-conversation watermarks are in-process only.

- Rig-managed conversation memory:
  - New `rig::memory` module with the `ConversationMemory` trait,
    `MemoryError` (with a `MemoryBackendError` source type),
    `MessageFilter` trait, and a default `InMemoryConversationMemory` backend
    with optional `with_filter` for shaping loaded history.
  - `AgentBuilder::memory(...)` and `AgentBuilder::conversation_id(...)` to
    attach a backend and an optional default conversation id to an agent.
  - `PromptRequest::conversation(id)` and `PromptRequest::without_memory()`
    (mirrored on the streaming builder) to control memory per-request.
  - `From<MemoryError> for PromptError` and `From<MemoryError> for
    StreamingError` so memory failures propagate via `?` through the existing
    `CompletionError::RequestError(Box<dyn Error>)` variant — no new
    top-level error variants, fully additive change.
  - `memory.append(...)` failures after a successful completion are
    best-effort: they emit `tracing::warn!` and the agent still returns the
    model response (parity for streaming `FinalResponse`). `memory.load(...)`
    failures remain fatal because the requested history is unavailable.
  - Examples: `agent_with_memory.rs` and `agent_with_memory_streaming.rs`.
  - Named history-shaping policies (sliding window, token budget) live in the
    new companion crate `rig-memory`.
- `rig::memory::DemotionHook` trait and `NoopDemotionHook` no-op default.
  Side-channel for messages that a memory policy or adapter removes from
  active history. Defined in `rig-core` so any memory backend can implement
  it without a `rig-memory` dependency; the composing
  `DemotingPolicyMemory<M, P, H>` adapter lives in `rig-memory`. Includes a
  forwarding `impl<H: DemotionHook + ?Sized> DemotionHook for Arc<H>` so
  hooks can be shared across multiple adapters.
- `MemoryError::Internal(String)` variant for in-process invariant
  violations (e.g. poisoned mutex guards), distinct from
  `MemoryError::Backend` which is reserved for failures of the underlying
  conversation store. `MemoryError` is now `#[non_exhaustive]` so future
  variants are not breaking changes.

  **Note for downstream crates:** `MemoryError` was previously a plain
  enum, so any existing `match` against it without a wildcard arm will
  now warn (and may need a wildcard arm if it was upgraded to a hard
  error elsewhere). Adding `_ => ...` is forward-compatible with future
  variants.

## [0.36.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.35.0...rig-core-v0.36.0) - 2026-04-28

### Added

- *(core)* add Xiaomi MiMo ([#1685](https://github.com/0xPlaygrounds/rig/pull/1685)) (by @BigtoC)
- rustls by default for everything ([#1682](https://github.com/0xPlaygrounds/rig/pull/1682)) (by @gold-silver-copper) - #1682
- gpt image 2, gpt 5.5, opus 4.7  ([#1679](https://github.com/0xPlaygrounds/rig/pull/1679)) (by @gold-silver-copper) - #1679
- *(core)* add DeepSeek model listing api ([#1672](https://github.com/0xPlaygrounds/rig/pull/1672)) (by @BigtoC)
- *(deepseek)* deprecate old model names ([#1664](https://github.com/0xPlaygrounds/rig/pull/1664)) (by @fu050409)
- *(ollama)* allow setting base_url and api_key programmatically ([#1511](https://github.com/0xPlaygrounds/rig/pull/1511)) (by @majiayu000)
- *(rig-core)* add ChatGPT Subscription, GitHub Copilot, and compatibility providers ([#1615](https://github.com/0xPlaygrounds/rig/pull/1615)) (by @wey-gu)
- *(providers)* add GitHub Copilot provider with relaxed response parsing ([#1451](https://github.com/0xPlaygrounds/rig/pull/1451)) (by @DAMEK86)
- *(rig-core)* Add model listing capability to OpenRouter client ([#1627](https://github.com/0xPlaygrounds/rig/pull/1627)) (by @nate-trojian)
- *(rig-derive)* support custom tool names ([#1619](https://github.com/0xPlaygrounds/rig/pull/1619)) ([#1620](https://github.com/0xPlaygrounds/rig/pull/1620)) (by @qaqland)

### Fixed

- pass generic parameter to gemini capability types ([#1687](https://github.com/0xPlaygrounds/rig/pull/1687)) (by @FayCarsons) - #1687
- *(openai)* carry reasoning_content on assistant tool-call messages ([#1649](https://github.com/0xPlaygrounds/rig/pull/1649)) (by @indrazm)
- preserve multimodal tool results in streaming chat history ([#1661](https://github.com/0xPlaygrounds/rig/pull/1661)) (by @gold-silver-copper) - #1661
- OpenAI text extraction  ([#1660](https://github.com/0xPlaygrounds/rig/pull/1660)) (by @gold-silver-copper) - #1660
- fixed n tests ([#1659](https://github.com/0xPlaygrounds/rig/pull/1659)) (by @gold-silver-copper) - #1659
- *(rig-1283)* handle llama.cpp reasoning_content as content ([#1657](https://github.com/0xPlaygrounds/rig/pull/1657)) (by @inqode-lars)
- *(responses_api)* add Unknown catch-all variant to Output enum ([#1552](https://github.com/0xPlaygrounds/rig/pull/1552)) (by @BillionClaw)

### Other

- Update permission_control.rs ([#1678](https://github.com/0xPlaygrounds/rig/pull/1678)) (by @gold-silver-copper) - #1678
- cleanup ([#1677](https://github.com/0xPlaygrounds/rig/pull/1677)) (by @gold-silver-copper) - #1677
- Add clippy no panic lints ([#1663](https://github.com/0xPlaygrounds/rig/pull/1663)) (by @gold-silver-copper) - #1663
- openai chat completions ([#1655](https://github.com/0xPlaygrounds/rig/pull/1655)) (by @gold-silver-copper) - #1655
- manual tool call example ([#1643](https://github.com/0xPlaygrounds/rig/pull/1643)) (by @gold-silver-copper) - #1643
- Remove `RwLock` from immutable state and execute futures concurrently ([#1641](https://github.com/0xPlaygrounds/rig/pull/1641)) (by @isSerge) - #1641
- Add Serialize/Deserialize derives to CompletionRequest, PromptResponse, TypedPromptResponse ([#1637](https://github.com/0xPlaygrounds/rig/pull/1637)) (by @geraschenko) - #1637
- wasm compat for model lister ([#1638](https://github.com/0xPlaygrounds/rig/pull/1638)) (by @gold-silver-copper) - #1638
- standardize required fields handling across builders ([#1611](https://github.com/0xPlaygrounds/rig/pull/1611)) (by @isSerge) - #1611
- remove deprecated code ([#1633](https://github.com/0xPlaygrounds/rig/pull/1633)) (by @gold-silver-copper) - #1633

### Contributors

* @BigtoC
* @FayCarsons
* @gold-silver-copper
* @fu050409
* @indrazm
* @inqode-lars
* @majiayu000
* @BillionClaw
* @isSerge
* @geraschenko
* @wey-gu
* @DAMEK86
* @nate-trojian
* @qaqland
## [0.35.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.34.0...rig-core-v0.35.0) - 2026-04-12

### Added

- *(rig-1197)* handle llama.cpp tool call ([#1408](https://github.com/0xPlaygrounds/rig/pull/1408)) ([#1409](https://github.com/0xPlaygrounds/rig/pull/1409)) (by @inqode-lars)

### Fixed

- *(#1604)* delay response_format on initial tool turns  (#1622) (by @gold-silver-copper)
- reduce `ToolServer` contention during tool lookup and execution ([#1607](https://github.com/0xPlaygrounds/rig/pull/1607)) (by @isSerge) - #1607
- *(streaming)* preserve tool call history, deduplicate prompt ([#1590](https://github.com/0xPlaygrounds/rig/pull/1590)) (by @gold-silver-copper)
- *(openai)* capture ResponseFailed errors in stream mode ([#1582](https://github.com/0xPlaygrounds/rig/pull/1582)) (by @gabrielrondon)

### Other

- (refactor): replace legacy Anthropic constants  ([#1616](https://github.com/0xPlaygrounds/rig/pull/1616)) (by @gold-silver-copper) - #1616
- Add ModelLister for Ollama, Anthropic, Mistral, OpenAI, Gemini ([#1587](https://github.com/0xPlaygrounds/rig/pull/1587)) (by @LHelge) - #1587
- gpt image 1.5 ([#1543](https://github.com/0xPlaygrounds/rig/pull/1543)) (by @kevinastock) - #1543
- *(rig-core)* [**breaking**] migrate examples to integration tests ([#1603](https://github.com/0xPlaygrounds/rig/pull/1603)) (by @gold-silver-copper)
- Do not stringify strings during tool output ([#1608](https://github.com/0xPlaygrounds/rig/pull/1608)) (by @gold-silver-copper) - #1608
- *(rig-core)* upgrade rmcp integration to 1.3, gate tests ([#1596](https://github.com/0xPlaygrounds/rig/pull/1596)) (by @gold-silver-copper)

### Contributors

* @gold-silver-copper
* @LHelge
* @kevinastock
* @isSerge
* @inqode-lars
* @gabrielrondon

## [0.34.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.33.0...rig-core-v0.34.0) - 2026-03-29

### Added

- *(rig-core)* respect custom Authorization headers set via http_headers() ([#1553](https://github.com/0xPlaygrounds/rig/pull/1553))
- make history generic and immutable ([#1563](https://github.com/0xPlaygrounds/rig/pull/1563))
- add grok xAI TTS ([#1530](https://github.com/0xPlaygrounds/rig/pull/1530))

### Fixed

- *(gemini)* infer string type for enum schemas in anyOf/oneOf ([#1547](https://github.com/0xPlaygrounds/rig/pull/1547))
- include assistant text in chat_history during multi-turn streaming ([#1560](https://github.com/0xPlaygrounds/rig/pull/1560))
- skip serializing encrypted_content when None ([#1534](https://github.com/0xPlaygrounds/rig/pull/1534))

### Other

- enable specifying native-tls instead of default rustls ([#1558](https://github.com/0xPlaygrounds/rig/pull/1558))
- Fix VoyageAI Usage deserialization failure on missing prompt_tokens ([#1568](https://github.com/0xPlaygrounds/rig/pull/1568))
- OTel GenAI semconv fix +  anthropic automatic prompt caching  ([#1572](https://github.com/0xPlaygrounds/rig/pull/1572))
- *(gemini)* Make `prompt_token_count` optional in gemini response ([#1548](https://github.com/0xPlaygrounds/rig/pull/1548))

## [0.33.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.32.0...rig-core-v0.33.0) - 2026-03-17

### Added

- *(rig-core)* add stateful WebSocket session for OpenAI Responses API ([#1500](https://github.com/0xPlaygrounds/rig/pull/1500))
- *(gemini)* add Gemini 3 model constants and thinking_level support ([#1520](https://github.com/0xPlaygrounds/rig/pull/1520))
- add llamafile provider ([#1519](https://github.com/0xPlaygrounds/rig/pull/1519))
- add grok imagine as image generation ([#1516](https://github.com/0xPlaygrounds/rig/pull/1516))
- *(rmcp)* `McpClientHandler` ([#1525](https://github.com/0xPlaygrounds/rig/pull/1525))
- *(telemetry)* emit gen_ai.usage.cached_tokens across all providers ([#1497](https://github.com/0xPlaygrounds/rig/pull/1497))
- add provider-native hosted tool support ([#1430](https://github.com/0xPlaygrounds/rig/pull/1430))

### Fixed

- *(openai)* make strict field optional in StructuredOutputsInput ([#1528](https://github.com/0xPlaygrounds/rig/pull/1528))
- *(llamafile)* apply embedding Number->f64 conversion for arbitrary_precision compat ([#1526](https://github.com/0xPlaygrounds/rig/pull/1526))
- embedding deserialization breaks with serde_json/arbitrary_precision ([#1518](https://github.com/0xPlaygrounds/rig/pull/1518))
- *(openai)* strengthen streaming tool call dedup to prevent false evictions ([#1510](https://github.com/0xPlaygrounds/rig/pull/1510))
- *(gemini)* [**breaking**] resolve embedding dimensions dynamically instead of hardcoding ([#1513](https://github.com/0xPlaygrounds/rig/pull/1513))
- *(gemini)* support URL-backed text documents ([#1507](https://github.com/0xPlaygrounds/rig/pull/1507))
- forward max_tokens in Chat Completions API requests ([#1495](https://github.com/0xPlaygrounds/rig/pull/1495))
- populate cached_input_tokens in Chat Completions streaming ([#1485](https://github.com/0xPlaygrounds/rig/pull/1485))
- *(gemini)* correct ProviderBuilder impl for GeminiInteractionsBuilder ([#1482](https://github.com/0xPlaygrounds/rig/pull/1482))
- *(rig-1218)* gemini MCP tool invalid tool argument ([#1462](https://github.com/0xPlaygrounds/rig/pull/1462))

### Other

- Change preamble to system message internally ([#1527](https://github.com/0xPlaygrounds/rig/pull/1527))
- fix link in rig-core README ([#1502](https://github.com/0xPlaygrounds/rig/pull/1502))
- Feat/gemini interactions api ([#1230](https://github.com/0xPlaygrounds/rig/pull/1230))


## [0.32.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.31.0...rig-core-v0.32.0) - 2026-03-05

### Added

- *(moonshot)* add Kimi K2 and K2.5 model constants ([#1457](https://github.com/0xPlaygrounds/rig/pull/1457)) (by @howardpen9)
- *(gemini)* add RAG extractor example and dynamic_context support ([#1456](https://github.com/0xPlaygrounds/rig/pull/1456)) (by @atellou)
- *(gemini)* Add support for RAG documents in dynamic context ([#1205](https://github.com/0xPlaygrounds/rig/pull/1205)) (by @snaumov)
- *(rig-core)* return conversation messages from non-streaming agent loop ([#1450](https://github.com/0xPlaygrounds/rig/pull/1450)) (by @illegalcall)
- *(extractor)* expose token usage via extract_with_usage methods ([#1447](https://github.com/0xPlaygrounds/rig/pull/1447)) (by @liamwh)
- add `.extended_details` to `TypedPromptRequest` via typestate ([#1446](https://github.com/0xPlaygrounds/rig/pull/1446)) (by @0xMochan) - #1446
- *(mistral)* implements audio transcription api ([#1424](https://github.com/0xPlaygrounds/rig/pull/1424)) (by @renanvieira)
- Reify SSE state machine ([#1428](https://github.com/0xPlaygrounds/rig/pull/1428)) (by @FayCarsons) - #1428
- feat(openrouter) Add support for openrouter embeddings ([#1418](https://github.com/0xPlaygrounds/rig/pull/1418)) ([#1419](https://github.com/0xPlaygrounds/rig/pull/1419)) (by @Lochlanna) - #1419
- *(azure-openai)* Add structured outputs support ([#1407](https://github.com/0xPlaygrounds/rig/pull/1407)) (by @austinsimpsond41)
- *(openrouter)* support audio and video ([#1413](https://github.com/0xPlaygrounds/rig/pull/1413)) (by @micllam)

### Fixed

- *(rig-1210)* deepseek content should not split into separate messages ([#1460](https://github.com/0xPlaygrounds/rig/pull/1460)) (by @joshua-mo-143)
- *(rig-1209)* reasoning content dropped from deepseektool messages ([#1459](https://github.com/0xPlaygrounds/rig/pull/1459)) (by @joshua-mo-143)
- *(openai)* add reasoning_content to StreamingDelta for OpenAI-compatible providers ([#1441](https://github.com/0xPlaygrounds/rig/pull/1441)) (by @Fromsko)
- properly support PDF doc URLs (anthropic) ([#1431](https://github.com/0xPlaygrounds/rig/pull/1431)) (by @joshua-mo-143) - #1431
- URL doc returns HTTP 400 (OpenAI) ([#1432](https://github.com/0xPlaygrounds/rig/pull/1432)) (by @joshua-mo-143) - #1432
- `total_usage` -> `usage` ([#1453](https://github.com/0xPlaygrounds/rig/pull/1453)) (by @0xMochan) - #1453
- *(deps)* enable reqwest system-proxy for proxy env var support ([#1442](https://github.com/0xPlaygrounds/rig/pull/1442)) (by @Phoenix500526)
- *(streaming)* disambiguate tool calls sharing the same index from API gateways ([#1443](https://github.com/0xPlaygrounds/rig/pull/1443)) (by @Phoenix500526)
- allow empty arguments openrouter ([#1438](https://github.com/0xPlaygrounds/rig/pull/1438)) (by @CremboC) - #1438

### Other

- *(rig-1220)* mark rig-eternalai deprecated ([#1472](https://github.com/0xPlaygrounds/rig/pull/1472)) (by @joshua-mo-143)
- *(rig-1200)* improve Client::builder DX ([#1436](https://github.com/0xPlaygrounds/rig/pull/1436)) (by @FayCarsons)
- *(deps)* update rmcp types for v0.16 API compatibility ([#1410](https://github.com/0xPlaygrounds/rig/pull/1410)) (by @adrianncovaci)

### Contributors

* @joshua-mo-143
* @Fromsko
* @howardpen9
* @atellou
* @snaumov
* @0xMochan
* @illegalcall
* @liamwh
* @Phoenix500526
* @FayCarsons
* @CremboC
* @renanvieira
* @Lochlanna
* @austinsimpsond41
* @adrianncovaci
* @micllam

## [0.31.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.30.0...rig-core-v0.31.0) - 2026-02-17

### Added

- *(rig-1192)* support pdf, image (openrouter) ([#1404](https://github.com/0xPlaygrounds/rig/pull/1404))
- cross-provider reasoning trace roundtrip ([#1396](https://github.com/0xPlaygrounds/rig/pull/1396))
- *(openrouter)* Add provider selection and prioritization support ([#1373](https://github.com/0xPlaygrounds/rig/pull/1373))
- *(rig-1189)* structured outputs ([#1382](https://github.com/0xPlaygrounds/rig/pull/1382))
- *(rig-core)* add optional model override to CompletionRequest ([#1374](https://github.com/0xPlaygrounds/rig/pull/1374))
- *(rig-1180)* support text docs (anthropic) ([#1377](https://github.com/0xPlaygrounds/rig/pull/1377))
- Add model listing capability ([#1243](https://github.com/0xPlaygrounds/rig/pull/1243))
- *(rig-1168)* add default prompt hook to agent (breaking) ([#1356](https://github.com/0xPlaygrounds/rig/pull/1356))
- [**breaking**] upgrade reqwest to 0.13 with rustls as default TLS backend ([#1218](https://github.com/0xPlaygrounds/rig/pull/1218))
- *(rig-1182)* single-text serialization to single string (openai) ([#1367](https://github.com/0xPlaygrounds/rig/pull/1367))
- add reqwest middleware example ([#1359](https://github.com/0xPlaygrounds/rig/pull/1359))

### Fixed

- *(rig-1195)* image urls don't work with anthropic ([#1403](https://github.com/0xPlaygrounds/rig/pull/1403))
- *(agents)* correct prompt hook docs, split modules, and fix install script ([#1384](https://github.com/0xPlaygrounds/rig/pull/1384))
- fix ollama dims miss ([#1199](https://github.com/0xPlaygrounds/rig/pull/1199))
- *(rig-1182)* assistantcontent serialization when empty (openai) ([#1369](https://github.com/0xPlaygrounds/rig/pull/1369))
- *(rig-1183)* invalid options provided (ollama) ([#1365](https://github.com/0xPlaygrounds/rig/pull/1365))

### Other

- add client builder test to all providers ([#1385](https://github.com/0xPlaygrounds/rig/pull/1385))
- add ironclaw ([#1400](https://github.com/0xPlaygrounds/rig/pull/1400))
- typed reasoning content model ([#1395](https://github.com/0xPlaygrounds/rig/pull/1395))
- *(streaming)* return updated history in FinalResponse ([#1210](https://github.com/0xPlaygrounds/rig/pull/1210))
- *(rig-1184)* remove AgentBuilderSimple ([#1368](https://github.com/0xPlaygrounds/rig/pull/1368))
- propagate current span to tool call ([#1361](https://github.com/0xPlaygrounds/rig/pull/1361))
- *(rig-1176)* unify prompt hook interfaces ([#1352](https://github.com/0xPlaygrounds/rig/pull/1352))

## [0.30.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.29.0...rig-core-v0.30.0) - 2026-02-03

### Added

- *(rig-1160)* encode control flow directly in type signature for hooks (breaking) ([#1305](https://github.com/0xPlaygrounds/rig/pull/1305))
- *(rig-1126)* tool image result support for gemini ([#1329](https://github.com/0xPlaygrounds/rig/pull/1329))
- support xhigh reasoning effort ([#1319](https://github.com/0xPlaygrounds/rig/pull/1319))
- *(agent)* allow on_tool_call hook to reject tool execution ([#1284](https://github.com/0xPlaygrounds/rig/pull/1284))

### Fixed

- avoid duplicate role in responses input ([#1314](https://github.com/0xPlaygrounds/rig/pull/1314))
- *(providers)* fixed azure openai embedding dimension ([#1303](https://github.com/0xPlaygrounds/rig/pull/1303))
- *(rig-1174)* openai responses requires reasoning in history ([#1335](https://github.com/0xPlaygrounds/rig/pull/1335))
- *(rig-1170)* concurrent tool execution ([#1326](https://github.com/0xPlaygrounds/rig/pull/1326))
- *(rig-1167)* fix deepseek-reasoner v3.2 invoke ([#1333](https://github.com/0xPlaygrounds/rig/pull/1333))
- *(rig-1156)* impl VectorStoreIndexDyn for mongodb and milvus ([#1300](https://github.com/0xPlaygrounds/rig/pull/1300))
- *(rig-1154)* gemini API tools mismatch ([#1291](https://github.com/0xPlaygrounds/rig/pull/1291))
- *(providers)* re-export gemini EmbeddingModel and constants at module root ([#1292](https://github.com/0xPlaygrounds/rig/pull/1292))

### Other

- *(rig-1164)* rename max_depth & related to max_turns (BREAKING) ([#1323](https://github.com/0xPlaygrounds/rig/pull/1323))
- remove unnecessary feature requirement for test ([#1341](https://github.com/0xPlaygrounds/rig/pull/1341))
- *(rig-1157)* Update xAI to Responses API ([#1316](https://github.com/0xPlaygrounds/rig/pull/1316))
- *(rig-1171)* update ollama docs ([#1327](https://github.com/0xPlaygrounds/rig/pull/1327))
- *(rig-1163)* ollama stream tool calls get ignored ([#1309](https://github.com/0xPlaygrounds/rig/pull/1309))
- Handle error for HTTP client response ([#1237](https://github.com/0xPlaygrounds/rig/pull/1237))
- Add default type parameter T = reqwest::Client to ollama's EmbeddingModel for consistency with other providers ([#1293](https://github.com/0xPlaygrounds/rig/pull/1293))

## [0.29.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.28.0...rig-core-v0.29.0) - 2026-01-20

### Added

- improve vector store documentation and filter ergonomics (breaking) ([#1258](https://github.com/0xPlaygrounds/rig/pull/1258))
- *(rig-1142)* include agent names in tracing ([#1270](https://github.com/0xPlaygrounds/rig/pull/1270))
- *(rig-1144)* deepseek reasoning content (non-streaming) ([#1269](https://github.com/0xPlaygrounds/rig/pull/1269))
- *(rig-1147)* re-export reqwest client ([#1277](https://github.com/0xPlaygrounds/rig/pull/1277))
- add custom vector store backend example ([#1252](https://github.com/0xPlaygrounds/rig/pull/1252))
- add default max depth to agents ([#1253](https://github.com/0xPlaygrounds/rig/pull/1253))
- Add the `user` parameter to openai-embedding. ([#1254](https://github.com/0xPlaygrounds/rig/pull/1254))
- *(rig-1135)* Agentic loop early termination reason ([#1248](https://github.com/0xPlaygrounds/rig/pull/1248))
- Add the ```encoding_format``` parameter to openai-embedding. ([#1203](https://github.com/0xPlaygrounds/rig/pull/1203))

### Fixed

- *(agent)* fix CancelSignal cancellation and reason sharing bugs ([#1282](https://github.com/0xPlaygrounds/rig/pull/1282))
- *(rig-1140)* do not prepend a forward slash to blank base URLs ([#1275](https://github.com/0xPlaygrounds/rig/pull/1275))

### Other

- bump dependencies ([#1257](https://github.com/0xPlaygrounds/rig/pull/1257))
- *(rig-1145)* update code snippet ([#1268](https://github.com/0xPlaygrounds/rig/pull/1268))
- fix gemini streaming ([#1262](https://github.com/0xPlaygrounds/rig/pull/1262))
- Add `AgentBuilder::tools` for adding static tools dynamically ([#1236](https://github.com/0xPlaygrounds/rig/pull/1236))
- *(rig-core)* Fix gemini doc example with wrong imports ([#1238](https://github.com/0xPlaygrounds/rig/pull/1238))

## [0.28.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.27.0...rig-core-v0.28.0) - 2026-01-06

### Added

- *(agent)* export StreamingError to public API ([#1200](https://github.com/0xPlaygrounds/rig/pull/1200))

### Fixed

- some completion providers send usage chunks with 0 completion choices causing 0 reported usage ([#1211](https://github.com/0xPlaygrounds/rig/pull/1211))
- *(rig-1109)* export agent StreamingResult type ([#1220](https://github.com/0xPlaygrounds/rig/pull/1220))
- docs typo ([#1219](https://github.com/0xPlaygrounds/rig/pull/1219))
- missing json header on send_streaming ([#1196](https://github.com/0xPlaygrounds/rig/pull/1196))
- *(rig-1113)* `calculate_max_tokens` assumes known model (anthropic) ([#1216](https://github.com/0xPlaygrounds/rig/pull/1216))
- add headers to get call ([#1178](https://github.com/0xPlaygrounds/rig/pull/1178))
- deepseek stream_prompt Invalid status code 415 ([#1170](https://github.com/0xPlaygrounds/rig/pull/1170))
- *(openrouter)* add default serde attr to reasoning_details for optional field deserialization ([#1173](https://github.com/0xPlaygrounds/rig/pull/1173))

### Other

- add tool name to tool call delta streaming events ([#1222](https://github.com/0xPlaygrounds/rig/pull/1222))
- *(deps)* update rmcp dependency to 0.12.0 ([#1182](https://github.com/0xPlaygrounds/rig/pull/1182))
- *(deps)* upgrade rmcp dependency to 0.11 ([#1165](https://github.com/0xPlaygrounds/rig/pull/1165))
- Respect custom http headers for outgoing client requests ([#1166](https://github.com/0xPlaygrounds/rig/pull/1166))

## [0.27.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.26.0...rig-core-v0.27.0) - 2025-12-15

### Added

- *(rig-1096)* pass tool call ID to prompt hook ([#1162](https://github.com/0xPlaygrounds/rig/pull/1162))
- *(rig-1059)* support `reqwest-middleware` client ([#1152](https://github.com/0xPlaygrounds/rig/pull/1152))

### Fixed

- *(groq)* rename StreamingOptions to StreamOptions ([#1159](https://github.com/0xPlaygrounds/rig/pull/1159))
- *(openai)* add None variant to ReasoningEffort enum ([#1158](https://github.com/0xPlaygrounds/rig/pull/1158))

### Other

- ToolCall Signature and additional parameters ([#1154](https://github.com/0xPlaygrounds/rig/pull/1154))
- fix incorrect variable name in AgentBuilder examples ([#1160](https://github.com/0xPlaygrounds/rig/pull/1160))
- *(rig-1085)* groq reasoning format ([#1151](https://github.com/0xPlaygrounds/rig/pull/1151))
- *(rig-1031)* remove worker crate dep ([#1149](https://github.com/0xPlaygrounds/rig/pull/1149))
- *(rig-1090)* crate re-org ([#1145](https://github.com/0xPlaygrounds/rig/pull/1145))

## [0.26.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.25.0...rig-core-v0.26.0) - 2025-12-04

### Added

- add Anthropic prompt caching support ([#1116](https://github.com/0xPlaygrounds/rig/pull/1116))
- *(rig-1076)* Providers should route all requests through `client::Client` ([#1115](https://github.com/0xPlaygrounds/rig/pull/1115))

### Fixed

- *(streaming)* use .instrument() instead of span.enter() to prevent span leak ([#1108](https://github.com/0xPlaygrounds/rig/pull/1108))

### Other

- *(rig-1077)* ensure log level enabled before logging messages ([#1114](https://github.com/0xPlaygrounds/rig/pull/1114))
- *(rig-1078)* remove messages from span telemetry ([#1112](https://github.com/0xPlaygrounds/rig/pull/1112))

## [0.25.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.24.0...rig-core-v0.25.0) - 2025-12-01

### Added

- Gemini Assistant Image Responses ([#1048](https://github.com/0xPlaygrounds/rig/pull/1048))
- *(gemini-request)* add response_json_schema to GenerationConfig ([#1077](https://github.com/0xPlaygrounds/rig/pull/1077))
- *(rig-985)* Consolidate provider clients ([#1050](https://github.com/0xPlaygrounds/rig/pull/1050))

### Fixed

- *(rig-1093)* gemini config error when no additional params used ([#1094](https://github.com/0xPlaygrounds/rig/pull/1094))
- OpenAI required props for structured output ([#1090](https://github.com/0xPlaygrounds/rig/pull/1090))
- *(rig-1055)* remove deprecated gemini-2.5-flash preview ([#1084](https://github.com/0xPlaygrounds/rig/pull/1084))
- rmcp derive clone ([#1080](https://github.com/0xPlaygrounds/rig/pull/1080))
- *(rig-1050)* Inconsistent model/agent initialisation methods ([#1069](https://github.com/0xPlaygrounds/rig/pull/1069))
- *(gemini-request)* add `#[serde(default)]` for missing `generation_config` field ([#1060](https://github.com/0xPlaygrounds/rig/pull/1060))
- update imported packages in the code example ([#1041](https://github.com/0xPlaygrounds/rig/pull/1041))

### Other

- add `Content-Type: application/json` to regular http requests ([#1106](https://github.com/0xPlaygrounds/rig/pull/1106))
- Deprecate `DynClientBuilder` ([#1105](https://github.com/0xPlaygrounds/rig/pull/1105))
- `client::Client` can leak api keys that have been inserted into its headers ([#1102](https://github.com/0xPlaygrounds/rig/pull/1102))
- *(rig-1071)* remove outdated models ([#1096](https://github.com/0xPlaygrounds/rig/pull/1096))
- *(rig-1068)* remove unused chatbot module ([#1092](https://github.com/0xPlaygrounds/rig/pull/1092))
- Simple JSON passthrough unwrapper ([#1086](https://github.com/0xPlaygrounds/rig/pull/1086))
- *(rig-777)* proper request modelling for every provider ([#1067](https://github.com/0xPlaygrounds/rig/pull/1067))
- *(deps)* upgrade `rmcp` ([#1079](https://github.com/0xPlaygrounds/rig/pull/1079))
- OpenAI parsing ([#1058](https://github.com/0xPlaygrounds/rig/pull/1058))
- *(rig-1046)* update list of who's using rig ([#1061](https://github.com/0xPlaygrounds/rig/pull/1061))
- clean up provider code ([#1052](https://github.com/0xPlaygrounds/rig/pull/1052))

## [0.24.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.23.1...rig-core-v0.24.0) - 2025-11-10

### Added

- *(rig-1024)* yield tool calls and results from multi-step stream prompt ([#1023](https://github.com/0xPlaygrounds/rig/pull/1023))
- *(providers)* Emit tool call deltas ([#1020](https://github.com/0xPlaygrounds/rig/pull/1020))
- export rig tool macro from main crate ([#1016](https://github.com/0xPlaygrounds/rig/pull/1016))

### Fixed

- *(rig-1035)* export StreamingPromptHook ([#1039](https://github.com/0xPlaygrounds/rig/pull/1039))
- Gemini responses lacking content ([#1030](https://github.com/0xPlaygrounds/rig/pull/1030))
- *(rig-1029)* Reasoning not handled properly for agent stream prompt ([#1024](https://github.com/0xPlaygrounds/rig/pull/1024))
- *(openai-responses)* add `#[serde(default)]` for missing `tools` field ([#1021](https://github.com/0xPlaygrounds/rig/pull/1021))
- *(rig-1027)* allow any error type to be used for rig tool macro ([#1017](https://github.com/0xPlaygrounds/rig/pull/1017))

### Other

- make CompletionModel  default type to reqwest::Client ([#1013](https://github.com/0xPlaygrounds/rig/pull/1013))
- *(deps)* upgrade rmcp dependency ([#1008](https://github.com/0xPlaygrounds/rig/pull/1008))

## [0.23.1](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.23.0...rig-core-v0.23.1) - 2025-10-28

### Fixed

- compliance with OpenAI API  stream error "message":"Model field is required." ([#1006](https://github.com/0xPlaygrounds/rig/pull/1006))

## [0.23.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.22.0...rig-core-v0.23.0) - 2025-10-27

### Added

- *(rig-1021)* allow language to be set to None for transcription ([#997](https://github.com/0xPlaygrounds/rig/pull/997))
- *(rig-1008)* add Send + Sync to ProviderClient ([#974](https://github.com/0xPlaygrounds/rig/pull/974))
- *(rig-976)* support filters for `VectorSearchRequest` ([#952](https://github.com/0xPlaygrounds/rig/pull/952))
- *(rig-1004)* expose tool call partials ([#960](https://github.com/0xPlaygrounds/rig/pull/960))
- convert video media mime type ([#959](https://github.com/0xPlaygrounds/rig/pull/959))
- *(rig-996)* generic streaming ([#955](https://github.com/0xPlaygrounds/rig/pull/955))
- *(gemini)* Support streaming thinking ([#947](https://github.com/0xPlaygrounds/rig/pull/947))
- *(ollama)* thinking ([#948](https://github.com/0xPlaygrounds/rig/pull/948))
- *(anthropic)* Expose the reasoning signature ([#945](https://github.com/0xPlaygrounds/rig/pull/945))

### Fixed

- CompletionError: ProviderError: {"error":{"code":null,"param":null,"message":"[] is too short - 'tools'","type":"invalid_request_error"}} ([#1003](https://github.com/0xPlaygrounds/rig/pull/1003))
- *(rig-1023)* reasoning/thinking stream sends redundant data ([#1002](https://github.com/0xPlaygrounds/rig/pull/1002))
- *(rig-1022)* GenericEventSource polling None should not error ([#999](https://github.com/0xPlaygrounds/rig/pull/999))
- *(huggingface)* align tool message serialization with OpenAI API spec ([#993](https://github.com/0xPlaygrounds/rig/pull/993))
- *(rig-1020)* add `futures-timer/wasm-bindgen` feature for wasm ([#995](https://github.com/0xPlaygrounds/rig/pull/995))
- *(rig-1019)* fix potentially incorrect provider URLs ([#991](https://github.com/0xPlaygrounds/rig/pull/991))
- *(rig-1016)* Huggingface completions API 404 ([#986](https://github.com/0xPlaygrounds/rig/pull/986))
- *(rig-1011)* docs mismatch ([#981](https://github.com/0xPlaygrounds/rig/pull/981))
- *(rig-1007)* tool servers broken in WASM ([#970](https://github.com/0xPlaygrounds/rig/pull/970))
- *(rig-1009)* Incorrect struct shape (OpenAI) ([#973](https://github.com/0xPlaygrounds/rig/pull/973))
- *(rig-997)* allow string documents for OpenAI Completions API ([#966](https://github.com/0xPlaygrounds/rig/pull/966))
- *(rig-1006)* text-embedding-ada-002 doesn't support custom dimensions ([#967](https://github.com/0xPlaygrounds/rig/pull/967))
- *(agent)* Apply tool_choice to completion request ([#958](https://github.com/0xPlaygrounds/rig/pull/958))
- *(rig-1005)* enable toggling "think" on ollama ([#962](https://github.com/0xPlaygrounds/rig/pull/962))
- *(openrouter)* use reqwest_post helper to construct full URL ([#943](https://github.com/0xPlaygrounds/rig/pull/943))
- *(rig-995)* include max tokens in Moonshot API request ([#935](https://github.com/0xPlaygrounds/rig/pull/935))

### Other

- InvalidCodeWithMessage error enum variant ([#963](https://github.com/0xPlaygrounds/rig/pull/963))
- *(rig-1003)* update list of production rig users ([#956](https://github.com/0xPlaygrounds/rig/pull/956))
- make streaming prompt module pub ([#944](https://github.com/0xPlaygrounds/rig/pull/944))
- *(rig-993)* re-import all items from embeddings module in rig::embeddings ([#936](https://github.com/0xPlaygrounds/rig/pull/936))

## [0.22.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.21.0...rig-core-v0.22.0) - 2025-10-14

### Added

- *(rig-937)* evals ([#905](https://github.com/0xPlaygrounds/rig/pull/905))
- *(rig-986)* tool servers ([#916](https://github.com/0xPlaygrounds/rig/pull/916))
- *(rig-988)* cancel streaming prompts from prompt hook ([#918](https://github.com/0xPlaygrounds/rig/pull/918))
- *(rig-990)* allow configuring optional lancedb features ([#923](https://github.com/0xPlaygrounds/rig/pull/923))
- return usage when streaming completions from a dynamic client ([#903](https://github.com/0xPlaygrounds/rig/pull/903))
- *(rig-979)* discord bot integration ([#900](https://github.com/0xPlaygrounds/rig/pull/900))
- *(rig-935)* support cancelling multi-turn prompt loop from hook ([#904](https://github.com/0xPlaygrounds/rig/pull/904))
- *(rig-951)* generic HTTP client ([#875](https://github.com/0xPlaygrounds/rig/pull/875))
- *(rig-977)* add description field to Agent, update tool impl ([#895](https://github.com/0xPlaygrounds/rig/pull/895))
- *(rig-848)* extract JSON with chat history ([#888](https://github.com/0xPlaygrounds/rig/pull/888))
- *(rig-955)* set up tool choice capability for Extractor ([#884](https://github.com/0xPlaygrounds/rig/pull/884))
- *(rig-964)* add tool choice to agent ([#883](https://github.com/0xPlaygrounds/rig/pull/883))
- *(rig-973)* DocumentSourceKind::String ([#882](https://github.com/0xPlaygrounds/rig/pull/882))

### Fixed

- *(rig-991)* nested struct conversion to Gemini OpenAPI type schema ([#926](https://github.com/0xPlaygrounds/rig/pull/926))
- *(rig-982)* embedding_model_with_ndims() doesn't pass dimensions parameter to OpenAI API
- *(rig-983)* http request fail due to no content type header set ([#909](https://github.com/0xPlaygrounds/rig/pull/909))
- Correct data structure for OpenAI responses images and PDFs ([#880](https://github.com/0xPlaygrounds/rig/pull/880))

### Other

- *(rig-975)* split streaming portion of PromptHook ([#889](https://github.com/0xPlaygrounds/rig/pull/889))
- *(rig-975)* split streaming portion of PromptHook
- *(rig-959)* Documents in Huggingface are not converted properly ([#874](https://github.com/0xPlaygrounds/rig/pull/874))

## [0.21.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.20.0...rig-core-v0.21.0) - 2025-09-29

### Added

- GenAI SemConv support (otel) ([#850](https://github.com/0xPlaygrounds/rig/pull/850))
- add streaming support to DynClientBuilder ([#824](https://github.com/0xPlaygrounds/rig/pull/824))
- *(rig-912)* rework `Chat` trait for multi-turn ([#846](https://github.com/0xPlaygrounds/rig/pull/846))
- *(rig-795)* support file URLs for audio, video, documents ([#823](https://github.com/0xPlaygrounds/rig/pull/823))
- *(rig-943)* support thinking for cohere ([#827](https://github.com/0xPlaygrounds/rig/pull/827))

### Fixed

- only youtube videos should accept null mime type (gemini) ([#873](https://github.com/0xPlaygrounds/rig/pull/873))
- *(rig-970)* file URLs should be able to accept empty media type (Gemini) ([#872](https://github.com/0xPlaygrounds/rig/pull/872))
- *(rig-970)* youtube video ingestion doesn't work (gemini)
- fix(rig-962)(deepseek): tool calls not recognised when put behind text content ([#862](https://github.com/0xPlaygrounds/rig/pull/862))
- fix-853 ([#854](https://github.com/0xPlaygrounds/rig/pull/854))
- *(rig-956)* DocumentSourceKind fails to serialize with common serializers ([#849](https://github.com/0xPlaygrounds/rig/pull/849))
- *(rig-957)* huggingface should convert image URLs ([#848](https://github.com/0xPlaygrounds/rig/pull/848))
- *(rig-950)* openai imagegen doesn't work with gpt-image-1 ([#837](https://github.com/0xPlaygrounds/rig/pull/837))
- ci lints ([#832](https://github.com/0xPlaygrounds/rig/pull/832))

### Other

- *(rig-969)* update features on README ([#870](https://github.com/0xPlaygrounds/rig/pull/870))
- *(rig-963)* fix feature regression in AWS bedrock ([#863](https://github.com/0xPlaygrounds/rig/pull/863))
- fix typo in comment ([#866](https://github.com/0xPlaygrounds/rig/pull/866))
- parse NDJSON correctly, fixes #825 ([#826](https://github.com/0xPlaygrounds/rig/pull/826))
- make Reasoning non-exhaustive ([#830](https://github.com/0xPlaygrounds/rig/pull/830))

## [0.20.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.19.0...rig-core-v0.20.0) - 2025-09-15

### Added

- think tool, vector store tool, better agent tool ([#424](https://github.com/0xPlaygrounds/rig/pull/424))
- *(rig-926)* make agent multi stream prompting more granular ([#796](https://github.com/0xPlaygrounds/rig/pull/796))
- *(rig-928)* allow openai chat completions to be used as an extractor ([#797](https://github.com/0xPlaygrounds/rig/pull/797))
- *(rig-831)* ensure all features are added to docs.rs ([#801](https://github.com/0xPlaygrounds/rig/pull/801))
- *(rig-931)* support file input for images on Gemini ([#790](https://github.com/0xPlaygrounds/rig/pull/790))

### Fixed

- *(rig-939)* incomplete byte sequence error when streaming from OpenAI Responses ([#812](https://github.com/0xPlaygrounds/rig/pull/812))
- *(rig-933)* openai responses api integration does not properly take images ([#799](https://github.com/0xPlaygrounds/rig/pull/799))

### Other

- *(cohere)* use `reqwest-eventsource`, some code cleanup ([#815](https://github.com/0xPlaygrounds/rig/pull/815))
- *(openAI, openrouter, deepseek, groq)* use `reqwest-eventsource` ([#814](https://github.com/0xPlaygrounds/rig/pull/814))
- remove unnecessary clone ([#808](https://github.com/0xPlaygrounds/rig/pull/808))
- *(rig-924)* update rmcp to 0.6 ([#785](https://github.com/0xPlaygrounds/rig/pull/785))
- optional candidates token count ([#793](https://github.com/0xPlaygrounds/rig/pull/793))
- allow prompt without preamble ([#791](https://github.com/0xPlaygrounds/rig/pull/791))

## [0.19.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.18.2...rig-core-v0.19.0) - 2025-09-02

### Added

- *(rig-core)* add fn cli_chatbot() back ([#769](https://github.com/0xPlaygrounds/rig/pull/769))
- *(rig-918)* expose more token usage metadata metrics for gemini ([#768](https://github.com/0xPlaygrounds/rig/pull/768))
- *(rig-911)* ConvertMessage trait ([#753](https://github.com/0xPlaygrounds/rig/pull/753))
- *(openai responses)* add `minimal` variant to ReasoningEffort ([#765](https://github.com/0xPlaygrounds/rig/pull/765))
- *(rig-904)* Rework CLI chatbot integration ([#756](https://github.com/0xPlaygrounds/rig/pull/756))
- Pauseable streams ([#733](https://github.com/0xPlaygrounds/rig/pull/733))
- *(rig-910)* function calls fail when using OpenAI Responses API with reasoning models ([#754](https://github.com/0xPlaygrounds/rig/pull/754))
- *(rig-901)* Make multi-turn stream return a `Send + 'static` stream ([#739](https://github.com/0xPlaygrounds/rig/pull/739))
- VerifyClient trait ([#724](https://github.com/0xPlaygrounds/rig/pull/724))
- *(rig-898)* make MultiTurnStreamItem pub ([#735](https://github.com/0xPlaygrounds/rig/pull/735))

### Fixed

- *(rig-core examples)* add `required` field to calculator example tool definitions ([#757](https://github.com/0xPlaygrounds/rig/pull/757))
- *(openai responses)* recursively add additionalProperties: false to nested schemas ([#755](https://github.com/0xPlaygrounds/rig/pull/755))
- empty type in Vec<T> schema conversion for Gemini API ([#721](https://github.com/0xPlaygrounds/rig/pull/721)) ([#748](https://github.com/0xPlaygrounds/rig/pull/748))

### Other
- 修改文档错误 ([#771](https://github.com/0xPlaygrounds/rig/pull/771))
- *(rig-907)* use where clause for trait bounds ([#749](https://github.com/0xPlaygrounds/rig/pull/749))
- *(rig-913)* add feature gated items to docs ([#764](https://github.com/0xPlaygrounds/rig/pull/764))
- Remove duplicate methods in perplexity ([#725](https://github.com/0xPlaygrounds/rig/pull/725))

## [0.18.2](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.18.1...rig-core-v0.18.2) - 2025-08-20

### Fixed

- docs are broken (...again) ([#722](https://github.com/0xPlaygrounds/rig/pull/722))

## [0.18.1](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.18.0...rig-core-v0.18.1) - 2025-08-19

### Fixed

- *(rig-890)* docs are broken ([#718](https://github.com/0xPlaygrounds/rig/pull/718))

## [0.18.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.17.1...rig-core-v0.18.0) - 2025-08-19

### Added

- *(rig-865)* multi turn streaming ([#712](https://github.com/0xPlaygrounds/rig/pull/712))
- implement Tool for Agent ([#704](https://github.com/0xPlaygrounds/rig/pull/704))
- Add capability to add custom logic while running prompts ([#632](https://github.com/0xPlaygrounds/rig/pull/632))
- *(rig-863)* add retries to extractor tool ([#685](https://github.com/0xPlaygrounds/rig/pull/685))
- *(gemini)* Accept plain-text tool result ([#686](https://github.com/0xPlaygrounds/rig/pull/686))
- video input for gemini ([#690](https://github.com/0xPlaygrounds/rig/pull/690))
- added get_tool_definitions ([#666](https://github.com/0xPlaygrounds/rig/pull/666))

### Fixed

- *(rig-886)* only GenerationConfig can be passed into additional_params ([#707](https://github.com/0xPlaygrounds/rig/pull/707))
- deepseek streaming endpoint ([#687](https://github.com/0xPlaygrounds/rig/pull/687))
- *(rig-864)* missing id from OpenAI Responses API for reasoning items ([#681](https://github.com/0xPlaygrounds/rig/pull/681))

### Other

- *(rig-883)* fully deprecate mcp feature flag ([#714](https://github.com/0xPlaygrounds/rig/pull/714))
- *(gemini)* Refactor parts to Vec instead of OneOrMany in Gemini ([#691](https://github.com/0xPlaygrounds/rig/pull/691))
- consistent visibility modifiers in openai ([#694](https://github.com/0xPlaygrounds/rig/pull/694))
- Update rmcp to version 0.5 ([#682](https://github.com/0xPlaygrounds/rig/pull/682))
- Fix SSE parsing in Gemini provider ([#683](https://github.com/0xPlaygrounds/rig/pull/683))
- *(rig-862)* remove sync bound from fn call() in tool trait ([#678](https://github.com/0xPlaygrounds/rig/pull/678))
- 删除gemini providers中重复的方法 ([#675](https://github.com/0xPlaygrounds/rig/pull/675))

## [0.17.1](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.17.0...rig-core-v0.17.1) - 2025-08-05

### Other

- remove unnecessary warning traces ([#672](https://github.com/0xPlaygrounds/rig/pull/672))
- *(rig-851)* update provider integrations list ([#651](https://github.com/0xPlaygrounds/rig/pull/651))

## [0.17.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.16.0...rig-core-v0.17.0) - 2025-08-05

### Added

- *(rig-845)* cosine similarity for vector search ([#664](https://github.com/0xPlaygrounds/rig/pull/664))
- add `delete_tool` method to `Toolset` ([#663](https://github.com/0xPlaygrounds/rig/pull/663))
- Read the OPENAI_BASE_URL env variable when constructing an OpenAI client from_env ([#659](https://github.com/0xPlaygrounds/rig/pull/659))
- add agent name ([#633](https://github.com/0xPlaygrounds/rig/pull/633))

### Fixed

- *(rig-853)* gemini streaming impl ignores reasoning chunks ([#654](https://github.com/0xPlaygrounds/rig/pull/654))
- Ollama provider handling of canonical URLs ([#656](https://github.com/0xPlaygrounds/rig/pull/656))
- *(rig-852)* dynamic context does not work correctly with ollama ([#660](https://github.com/0xPlaygrounds/rig/pull/660))

### Other

- *(rig-861)* make Agent<M> non-exhaustive ([#670](https://github.com/0xPlaygrounds/rig/pull/670))

## [0.16.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.15.1...rig-core-v0.16.0) - 2025-07-30

### Added

- *(rig-798)* `rig-wasm` ([#611](https://github.com/0xPlaygrounds/rig/pull/611))
- *(rig-819)* vector store index request struct ([#623](https://github.com/0xPlaygrounds/rig/pull/623))
- *(rig-830)* map documents to text for OpenAI Response API ([#622](https://github.com/0xPlaygrounds/rig/pull/622))
- Add GROK_4 model constant to xAI provider ([#614](https://github.com/0xPlaygrounds/rig/pull/614))
- *(rig-812)* yield final response with total usage metrics from streaming completion response in stream impl ([#584](https://github.com/0xPlaygrounds/rig/pull/584))
- *(rig-799)* add support for official rust sdk for mcp ([#553](https://github.com/0xPlaygrounds/rig/pull/553))
- *(rig-823)* impl size hint for OneOrMany types ([#606](https://github.com/0xPlaygrounds/rig/pull/606))
- *(rig-784)* thinking/reasoning ([#557](https://github.com/0xPlaygrounds/rig/pull/557))
- *(rig-821)* add tracing when submit tool is never called in extractor ([#603](https://github.com/0xPlaygrounds/rig/pull/603))
- make PromptResponse public ([#593](https://github.com/0xPlaygrounds/rig/pull/593))

### Fixed

- *(rig-824)* ToolResultContent should be serde-tagged ([#621](https://github.com/0xPlaygrounds/rig/pull/621))
- *(rig-828)* support done message on openai streaming completions api ([#619](https://github.com/0xPlaygrounds/rig/pull/619))
- *(rig-827)* openai responses streaming api placeholder panic ([#620](https://github.com/0xPlaygrounds/rig/pull/620))
- *(rig-834)* erroeneous tracing log level ([#626](https://github.com/0xPlaygrounds/rig/pull/626))
- *(rig-820)* ensure call ID is properly propagated ([#601](https://github.com/0xPlaygrounds/rig/pull/601))

### Other

- Add new claude models and default max tokens ([#634](https://github.com/0xPlaygrounds/rig/pull/634))
- *(rig-836)* deprecate mcp-core integration ([#631](https://github.com/0xPlaygrounds/rig/pull/631))
- Refactor clients with builder pattern ([#615](https://github.com/0xPlaygrounds/rig/pull/615))
- change log level to debug for input/output ([#627](https://github.com/0xPlaygrounds/rig/pull/627))
- fix spelling issue  ([#607](https://github.com/0xPlaygrounds/rig/pull/607))

### Migration
- If you are using `Client::from_url()`, you will now need to use `Client::builder()` and add it in from there. Otherwise if you don't care about changing your inner HTTP client or changing the base URL, you can still use `Client::new(<api_key_here>)` or `Client::from_env()` to achieve the same result as you normally would.
- `VectorStoreIndex` and `VectorStoreIndexDyn` now take a `rig::vector_search::VectorSearchRequest`, instead of a query and max result size. This has been done to enable much more ergonomic requesting in the future. Please see any of the `vector_search` examples for practical usage.
- The final response of a completion stream now yields the completion usage from the stream itself. You may wish to adjust your code to account for this.
- The `mcp-core` integration is now officially deprecated because the official Rust MCP SDK is now supported as it has feature parity. You will need to ensure you have moved to the `rmcp` integration (`rmcp` feature flag) by Rig 0.18.0 at the earliest.
- ToolResultContent is now `#[serde(tag = "type")]`. If you're storing the serialized Rig structs anywhere as JSON, you may need to account for this and write a script to backfill your stored JSON.

## [0.15.1](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.15.0...rig-core-v0.15.1) - 2025-07-16

### Fixed

- *(rig-815)* gemini completion fails when used with no tools ([#589](https://github.com/0xPlaygrounds/rig/pull/589))

## [0.15.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.14.0...rig-core-v0.15.0) - 2025-07-14

### Added

- *(rig-801)* DynClientBuilder::from_values ([#556](https://github.com/0xPlaygrounds/rig/pull/556))
- add `.extended_details` to `PromptRequest` ([#555](https://github.com/0xPlaygrounds/rig/pull/555))

### Fixed

- *(rig-811)* ollama fails to return results from multiple tools ([#581](https://github.com/0xPlaygrounds/rig/pull/581))
- *(rig-810)* prompting OpenAI reponses with message history fails ([#578](https://github.com/0xPlaygrounds/rig/pull/578))
- *(rig-809)* gemini function declarations should not be OneOrMany ([#576](https://github.com/0xPlaygrounds/rig/pull/576))

## [0.14.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.13.0...rig-core-v0.14.0) - 2025-07-07

### Added

- support inserting documents as a trait ([#563](https://github.com/0xPlaygrounds/rig/pull/563))
- Add max_tokens method to ExtractorBuilder ([#560](https://github.com/0xPlaygrounds/rig/pull/560))
- *(rig-780)* integrate openAI responses API ([#508](https://github.com/0xPlaygrounds/rig/pull/508))
- Stream cancellation using AbortHandle ([#525](https://github.com/0xPlaygrounds/rig/pull/525))
- *(rig-779)* allow extractor to be turned into inner agent ([#502](https://github.com/0xPlaygrounds/rig/pull/502))
- *(ollama)* add support for OLLAMA_API_BASE_URL environment var ([#541](https://github.com/0xPlaygrounds/rig/pull/541))
- *(rig-766)* add support for Voyage AI ([#493](https://github.com/0xPlaygrounds/rig/pull/493))
- *(rig-789)* add support for loading in pdfs/files as Vec<u8> ([#523](https://github.com/0xPlaygrounds/rig/pull/523))
- multi turn streaming example ([#413](https://github.com/0xPlaygrounds/rig/pull/413))
- *(rig-754)* support custom client configurations ([#511](https://github.com/0xPlaygrounds/rig/pull/511))

### Fixed

- Retain multi-turn tool call results in case of response error ([#526](https://github.com/0xPlaygrounds/rig/pull/526))
- *(rig-794)* parse openAI SSE response error ([#545](https://github.com/0xPlaygrounds/rig/pull/545))
- *(rig-796)* OpenRouter extractor fails ([#544](https://github.com/0xPlaygrounds/rig/pull/544))
- *(rig-792)* inconsistent implementations of with_custom_client ([#530](https://github.com/0xPlaygrounds/rig/pull/530))
- *(rig-783)* tool call example doesn't work with Gemini and OpenRouter ([#515](https://github.com/0xPlaygrounds/rig/pull/515))
- *(rig-773)* xAI embeddings endpoint is wrong ([#492](https://github.com/0xPlaygrounds/rig/pull/492))

### Other

- *(rig-803)* improve documentation for multi-turn ([#562](https://github.com/0xPlaygrounds/rig/pull/562))
- Migrate all crates to Rust 2024 ([#539](https://github.com/0xPlaygrounds/rig/pull/539))
- update deps ([#543](https://github.com/0xPlaygrounds/rig/pull/543))
- Declare shared dependencies in workspace ([#538](https://github.com/0xPlaygrounds/rig/pull/538))
- error fixes for clarity
- Make clippy happy on all targets ([#542](https://github.com/0xPlaygrounds/rig/pull/542))
- *(rig-791)* documents not consistently added to DeepSeek prompts ([#528](https://github.com/0xPlaygrounds/rig/pull/528))
- Fix `ToolResult` serialization in ollama provider ([#504](https://github.com/0xPlaygrounds/rig/pull/504))

## [0.13.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.12.0...rig-core-v0.13.0) - 2025-06-09

### Added

- add additional Gemini completion models ([#498](https://github.com/0xPlaygrounds/rig/pull/498))
- *(rig-758)* the extractor can pass additional params to be passed to the model ([#473](https://github.com/0xPlaygrounds/rig/pull/473))
- *(rig-744)* Add support for Milvus vector store ([#463](https://github.com/0xPlaygrounds/rig/pull/463))
- Improve Streaming API ([#388](https://github.com/0xPlaygrounds/rig/pull/388))

### Fixed

- OpenAI provider streaming tool call response for local LLM ([#442](https://github.com/0xPlaygrounds/rig/pull/442))
- *(rig-761)* ollama drops tool call results ([#478](https://github.com/0xPlaygrounds/rig/pull/478))
- Update of xAI model list ([#486](https://github.com/0xPlaygrounds/rig/pull/486))
- *(rig-757)* CI fails because of new clippy lints ([#470](https://github.com/0xPlaygrounds/rig/pull/470))
- *(extractor)* correct typo in extractor prompt ([#460](https://github.com/0xPlaygrounds/rig/pull/460))
- *(message)* correct ToolCall to Message conversion ([#461](https://github.com/0xPlaygrounds/rig/pull/461))
- Fix `dims` value for gemini's `EMBEDDING_004` ([#452](https://github.com/0xPlaygrounds/rig/pull/452)) ([#453](https://github.com/0xPlaygrounds/rig/pull/453))
- bump mcp-core to latest version and fixed breaking changes ([#443](https://github.com/0xPlaygrounds/rig/pull/443))

### Other

- Fix typo in AudioGenerationModel field name ([#487](https://github.com/0xPlaygrounds/rig/pull/487))
- Introduce Client Traits and Testing ([#440](https://github.com/0xPlaygrounds/rig/pull/440))
- Only PDF docs are supported by their API ([#465](https://github.com/0xPlaygrounds/rig/pull/465))
- Add mistral provider ([#437](https://github.com/0xPlaygrounds/rig/pull/437))
- `impl {Debug,Clone} for CompletionRequest` ([#457](https://github.com/0xPlaygrounds/rig/pull/457))
- fix some typos in comment ([#445](https://github.com/0xPlaygrounds/rig/pull/445))

## [0.12.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.11.1...rig-core-v0.12.0) - 2025-04-29

### Added

- add gpt-image-1 ([#418](https://github.com/0xPlaygrounds/rig/pull/418))
- multi-turn / reasoning loops + parallel tool calling ([#370](https://github.com/0xPlaygrounds/rig/pull/370))

### Fixed

- system and developer messages for openai ([#430](https://github.com/0xPlaygrounds/rig/pull/430))
- o-series models + constants ([#426](https://github.com/0xPlaygrounds/rig/pull/426))
- dynamically pull rag text from chat history ([#425](https://github.com/0xPlaygrounds/rig/pull/425))
- rig tool macro struct not public ([#409](https://github.com/0xPlaygrounds/rig/pull/409))
- function call conversion typo ([#415](https://github.com/0xPlaygrounds/rig/pull/415))
- deepseek function call conversion typo ([#414](https://github.com/0xPlaygrounds/rig/pull/414))

### Other

- Donot use async closure + Bump mcp-core ([#428](https://github.com/0xPlaygrounds/rig/pull/428))
- Remove broken xAI reference link in embedding.rs ([#427](https://github.com/0xPlaygrounds/rig/pull/427))
- Style/trace gemini embedding ([#411](https://github.com/0xPlaygrounds/rig/pull/411))
- Update agent_with_huggingface.rs ([#401](https://github.com/0xPlaygrounds/rig/pull/401))

## [0.11.1](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.11.0...rig-core-v0.11.1) - 2025-04-12

### Added

- trait for embedding images ([#396](https://github.com/0xPlaygrounds/rig/pull/396))
- Add `rig_tool` macro ([#353](https://github.com/0xPlaygrounds/rig/pull/353))
- impl From<mcp_core::types::Tool> for ToolDefinition ([#385](https://github.com/0xPlaygrounds/rig/pull/385))
- AWS Bedrock provider ([#318](https://github.com/0xPlaygrounds/rig/pull/318))

### Fixed

- gemini embeddings does not work for multiple documents ([#386](https://github.com/0xPlaygrounds/rig/pull/386))
- deserialization error due to serde rename of tool result ([#374](https://github.com/0xPlaygrounds/rig/pull/374))

### Other

- Updated broken link xaiAPI in `completion.rs` ([#384](https://github.com/0xPlaygrounds/rig/pull/384))
- Fix Clippy warnings for doc indentation and Error::other usage ([#364](https://github.com/0xPlaygrounds/rig/pull/364))

## [0.11.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.10.0...rig-core-v0.11.0) - 2025-03-31

### Added

- Add audio generation to all providers ([#359](https://github.com/0xPlaygrounds/rig/pull/359))
- Add image generation to all providers that support it ([#357](https://github.com/0xPlaygrounds/rig/pull/357))
- *(provider)* cohere-v2 ([#350](https://github.com/0xPlaygrounds/rig/pull/350))

### Fixed

- no params tools definition for Gemini ([#363](https://github.com/0xPlaygrounds/rig/pull/363))
- *(openai)* serde rename for image_url UserContent ([#355](https://github.com/0xPlaygrounds/rig/pull/355))

### Other

- New model provider: Anthropic Claude 3.7 Addition ([#341](https://github.com/0xPlaygrounds/rig/pull/341))
- added mcp_tool + Example ([#335](https://github.com/0xPlaygrounds/rig/pull/335))

## [0.10.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.9.1...rig-core-v0.10.0) - 2025-03-17

### Added

- Add streaming to all model providers ([#347](https://github.com/0xPlaygrounds/rig/pull/347))
- OpenRouter support ([#344](https://github.com/0xPlaygrounds/rig/pull/344))
- add reqwest/rustls-tls support ([#339](https://github.com/0xPlaygrounds/rig/pull/339))
- add transcription to all providers that support it ([#336](https://github.com/0xPlaygrounds/rig/pull/336))
- Azure OpenAI Token Authentication ([#329](https://github.com/0xPlaygrounds/rig/pull/329))
- SSE/JSONL decoders ported from Anthropic TS SDK ([#332](https://github.com/0xPlaygrounds/rig/pull/332))
- mira integration ([#282](https://github.com/0xPlaygrounds/rig/pull/282))
- Huggingface provider integration ([#321](https://github.com/0xPlaygrounds/rig/pull/321))

### Fixed

- unnecessary `unwrap`, skip serializing empty vec ([#343](https://github.com/0xPlaygrounds/rig/pull/343))
- fix error handling for Qwen's responses when using tools ([#351](https://github.com/0xPlaygrounds/rig/pull/351))
- reqwest can not use SOCKS proxy ([#311](https://github.com/0xPlaygrounds/rig/pull/311))
- fix wrong debug message ([#342](https://github.com/0xPlaygrounds/rig/pull/342))

### Other

- Update openai.rs ([#340](https://github.com/0xPlaygrounds/rig/pull/340))
- support svg ([#333](https://github.com/0xPlaygrounds/rig/pull/333))

## [0.9.1](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.9.0...rig-core-v0.9.1) - 2025-03-03

### Added

- Transcription Model support ([#322](https://github.com/0xPlaygrounds/rig/pull/322))
- Add EpubFileLoader for EPUB file processing ([#192](https://github.com/0xPlaygrounds/rig/pull/192))
- add ollama client ([#285](https://github.com/0xPlaygrounds/rig/pull/285))
- *(openai)* add updated OpenAI model constants ([#314](https://github.com/0xPlaygrounds/rig/pull/314))
- support together AI ([#230](https://github.com/0xPlaygrounds/rig/pull/230))

### Fixed

- *(openai)* skip serializing empty tool_calls vector ([#327](https://github.com/0xPlaygrounds/rig/pull/327))
- *(openai)* correct some fields for tools ([#286](https://github.com/0xPlaygrounds/rig/pull/286))
- *(loaders)* bump lodpf to allow more PDFs to parse correctly ([#307](https://github.com/0xPlaygrounds/rig/pull/307))

### Other

- rename DeepSeek_R1.pdf to deepseek_r1.pdf ([#316](https://github.com/0xPlaygrounds/rig/pull/316))

## [0.9.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.8.0...rig-core-v0.9.0) - 2025-02-17

### Added

- *(streaming)* add `Send` to `StreamingResult` inner Stream (#302)
- groq integration (#263)

### Fixed

- xai agent prompt provider error (#305) (#306)
- enhance tracing messages (#287)
- *(gemini)* fixed tool calling + tool extractor demo (#297)
- o3-mini doesn't support temperature (#266)

### Other

- EchoChambers Example Integration ([#244](https://github.com/0xPlaygrounds/rig/pull/244))
- deepseek message to remove dependencies with openai (#283)

## [0.8.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.7.0...rig-core-v0.8.0) - 2025-02-10

### Added

- fastembed integration (#268)
- *(core)* overhaul message API (#199)
- Add support for Azure OpenAI (#234)
- support moonshot language model (#223)
- galadriel api integration (redux) (#265)
- add Galadriel API integration (#188)
- support extractor for deepseek (#255)
- support tools for DeepSeek provider (#251)
- streaming API implementation for Anthropic provider (#232)

### Fixed

- deepseek client auth (#279)
- *(galadriel)* missed fixes from messages pr (#270)

### Other

- fix spelling errors in `Makefile` and `message.rs` (#284)
- Correct `tracing::debug` message. ([#275](https://github.com/0xPlaygrounds/rig/pull/275))
- agent recipes (#215)
- Revert "feat: add Galadriel API integration ([#188](https://github.com/0xPlaygrounds/rig/pull/188))" ([#264](https://github.com/0xPlaygrounds/rig/pull/264))
- *(example)* fix grammar mistake (#260)
- Fix typos  "substract" → "subtract" ([#256](https://github.com/0xPlaygrounds/rig/pull/256))
- fix typos (#242)
- add more provider notes (#237)

## [0.7.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.6.1...rig-core-v0.7.0) - 2025-01-27

### Added

- Add hyperbolic inference API integration (#238)
- *(rig-eternalai)* add support for EternalAI onchain toolset (#205)
- *(pipeline)* Add conditional op (#200)
- Add support for DeepSeek (#220)

### Fixed

- *(providers)* provider wasm support (#245)
- Use of deprecated `prelude` module (#241)
- anthropic tool use (#168)

### Other

- Fix typos (#233)
- *(README)* add SQLite as a supported vector store (#201)

## [0.6.1](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.6.0...rig-core-v0.6.1) - 2025-01-13

### Added

- Add `from_url` method to Gemini client (#194)
- Feature flag for CF worker compatibility (#176) (#175)
- *(eternal-ai)* Eternal-AI provider for rig (#171)
- Add gpt-4o-mini to openai model list (#187)

### Fixed

- *(example)* ollama example uses wrong url

### Other

- Add additional check for empty tool_calls ([#166](https://github.com/0xPlaygrounds/rig/pull/166))
- Mock provider API in vector store integration tests (#186)
- fix comment (#182)
- fix various typos

## [0.6.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.5.0...rig-core-v0.6.0) - 2024-12-19

### Added

- agent pipelines (#131)
- *(rig-anthropic)* Add default `max_tokens` for standard models (#151)

### Fixed

- *(openai)* Make integration more general (#156)

### Other

- *(ollama-example)* implement example showcasing ollama (#148)
- *(embeddings)* add embedding distance calculator module (#142)

## [0.5.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.4.1...rig-core-v0.5.0) - 2024-12-03

### Added

- Improve `InMemoryVectorStore` API ([#130](https://github.com/0xPlaygrounds/rig/pull/130))
- embeddings API overhaul ([#120](https://github.com/0xPlaygrounds/rig/pull/120))
- *(provider)* xAI (grok) integration ([#106](https://github.com/0xPlaygrounds/rig/pull/106))

### Fixed

- *(rig-lancedb)* rag embedding filtering ([#104](https://github.com/0xPlaygrounds/rig/pull/104))

## [0.4.1](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.4.0...rig-core-v0.4.1) - 2024-11-13

### Other

- Inefficient context documents serialization ([#100](https://github.com/0xPlaygrounds/rig/pull/100))

## [0.4.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.3.0...rig-core-v0.4.0) - 2024-11-07

### Added

- *(gemini)* move system prompt to correct request field
- *(provider-gemini)* add support for gemini specific completion parameters
- *(provider-gemini)* add agent support in client
- *(provider-gemini)* add gemini embedding support
- *(provider-gemini)* add gemini support for basic completion
- *(provider-gemini)* add gemini API client

### Fixed

- *(gemini)* issue when additionnal param is empty
- docs imports and refs
- *(gemini)* missing param to be marked as optional in completion res

### Other

- Cargo fmt
- Add module level docs for the `tool` module
- Fix loaders module docs references
- Add docstrings to loaders module
- Improve main lib docs
- Add `all` feature flag to rig-core
- *(gemini)* add utility config docstring
- *(gemini)* remove try_from and use serde deserialization
- Merge branch 'main' into feat/model-provider/16-add-gemini-completion-embedding-models
- *(gemini)* separate gemini api types module, fix pr comments
- add debug trait to embedding struct
- *(gemini)* add addtionnal types from the official documentation, add embeddings example
- *(provider-gemini)* test pre-commits
- *(provider-gemini)* Update readme entries, add gemini agent example

## [0.3.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.2.1...rig-core-v0.3.0) - 2024-10-24

### Added

- Generalize `EmbeddingModel::embed_documents` with `IntoIterator`
- Add `from_env` constructor to Cohere and Anthropic clients
- Small optimization to serde_json object merging
- Add better error handling for provider clients

### Fixed

- Bad Anthropic request/response handling
- *(vector-index)* In memory vector store index incorrect search

### Other

- Made internal `json_utils` module private
- Update lib docs
- Made CompletionRequest helper method private to crate
- lint + fmt
- Simplify `agent_with_tools` example
- Fix docstring links
- Add nextest test runner to CI
- Merge pull request [#42](https://github.com/0xPlaygrounds/rig/pull/42) from 0xPlaygrounds/refactor(vector-store)/update-vector-store-index-trait

## [0.2.1](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.2.0...rig-core-v0.2.1) - 2024-10-01

### Fixed

- *(docs)* Docs still referring to old types

### Other

- Merge pull request [#45](https://github.com/0xPlaygrounds/rig/pull/45) from 0xPlaygrounds/fix/docs

## [0.2.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.1.0...rig-core-v0.2.0) - 2024-10-01

### Added

- anthropic models

### Fixed

- *(context)* displaying documents should be deterministic (sorted by alpha)
- *(context)* spin out helper method + add tests
- move context documents to user prompt message
- adjust version const naming
- implement review suggestions + renaming
- add `completion_request.documents` to `chat_history`
- adjust API to be cleaner + add docstrings

### Other

- Merge pull request [#43](https://github.com/0xPlaygrounds/rig/pull/43) from 0xPlaygrounds/fix/context-documents
- Merge pull request [#27](https://github.com/0xPlaygrounds/rig/pull/27) from 0xPlaygrounds/feat/anthropic
- Fix docstrings
- Deprecate RagAgent and Model in favor of versatile Agent
- Make RagAgent VectorStoreIndex dynamic trait objects

## [0.1.0](https://github.com/0xPlaygrounds/rig/compare/rig-core-v0.0.7...rig-core-v0.1.0) - 2024-09-16

### Added

- add o1-preview and o1-mini

### Fixed

- *(perplexity)* fix preamble and context in completion request
- clippy warnings

### Other

- Merge pull request [#18](https://github.com/0xPlaygrounds/rig/pull/18) from 0xPlaygrounds/feat/perplexity-support
- Add logging of http errors
- fmt code
