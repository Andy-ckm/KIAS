# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [0.4.6](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.4.5...rig-mongodb-v0.4.6) - 2026-05-13

### Other

- fix "a ancient" grammar in glarb-glarb sample text ([#1755](https://github.com/0xPlaygrounds/rig/pull/1755)) (by @abhicris) - #1755
- AGENTS.MD, CONTRIBUTING.MD, and docs ([#1714](https://github.com/0xPlaygrounds/rig/pull/1714)) (by @gold-silver-copper) - #1714
- improve project organization and create rig crate ([#1699](https://github.com/0xPlaygrounds/rig/pull/1699)) (by @gold-silver-copper) - #1699

### Contributors

* @abhicris
* @gold-silver-copper
## [0.4.5](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.4.4...rig-mongodb-v0.4.5) - 2026-04-28

### Other

- Add clippy no panic lints ([#1663](https://github.com/0xPlaygrounds/rig/pull/1663)) (by @gold-silver-copper) - #1663
- standardize required fields handling across builders ([#1611](https://github.com/0xPlaygrounds/rig/pull/1611)) (by @isSerge) - #1611

### Contributors

* @gold-silver-copper
* @isSerge
## [0.4.4](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.4.3...rig-mongodb-v0.4.4) - 2026-04-12

### Other

- updated the following local packages: rig-core

## [0.4.3](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.4.2...rig-mongodb-v0.4.3) - 2026-03-29

### Other

- updated the following local packages: rig-core

## [0.4.2](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.4.1...rig-mongodb-v0.4.2) - 2026-03-17

### Other

- updated the following local packages: rig-core


## [0.4.1](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.4.0...rig-mongodb-v0.4.1) - 2026-03-05

### Other

- updated the following local packages: rig-core

## [0.3.7](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.3.6...rig-mongodb-v0.3.7) - 2026-02-17

### Other

- *(streaming)* return updated history in FinalResponse ([#1210](https://github.com/0xPlaygrounds/rig/pull/1210))

## [0.3.6](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.3.5...rig-mongodb-v0.3.6) - 2026-02-03

### Fixed

- *(rig-1156)* impl VectorStoreIndexDyn for mongodb and milvus ([#1300](https://github.com/0xPlaygrounds/rig/pull/1300))

## [0.3.5](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.3.4...rig-mongodb-v0.3.5) - 2026-01-20

### Added

- improve vector store documentation and filter ergonomics (breaking) ([#1258](https://github.com/0xPlaygrounds/rig/pull/1258))
- make integration filters available to be used as rig agent rag store ([#1249](https://github.com/0xPlaygrounds/rig/pull/1249))

## [0.3.4](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.3.3...rig-mongodb-v0.3.4) - 2026-01-06

### Other

- updated the following local packages: rig-core

## [0.3.3](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.3.2...rig-mongodb-v0.3.3) - 2025-12-15

### Other

- *(rig-1090)* crate re-org ([#1145](https://github.com/0xPlaygrounds/rig/pull/1145))

## [0.3.2](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.3.1...rig-mongodb-v0.3.2) - 2025-12-04

### Other

- updated the following local packages: rig-core

## [0.3.1](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.3.0...rig-mongodb-v0.3.1) - 2025-12-01

### Added

- *(rig-985)* Consolidate provider clients ([#1050](https://github.com/0xPlaygrounds/rig/pull/1050))

### Fixed

- *(rig-1050)* Inconsistent model/agent initialisation methods ([#1069](https://github.com/0xPlaygrounds/rig/pull/1069))

## [0.3.0](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.26...rig-mongodb-v0.3.0) - 2025-11-10

### Added

- *(rig-1014)* add backend specific vector search filters ([#1032](https://github.com/0xPlaygrounds/rig/pull/1032))

## [0.2.26](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.25...rig-mongodb-v0.2.26) - 2025-10-28

### Other

- updated the following local packages: rig-core

## [0.2.25](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.24...rig-mongodb-v0.2.25) - 2025-10-27

### Added

- *(rig-976)* support filters for `VectorSearchRequest` ([#952](https://github.com/0xPlaygrounds/rig/pull/952))

### Fixed

- *(rig-1006)* text-embedding-ada-002 doesn't support custom dimensions ([#967](https://github.com/0xPlaygrounds/rig/pull/967))

### Other

- Dependent packages no longer force unnecessary features on rig-core ([#964](https://github.com/0xPlaygrounds/rig/pull/964))

## [0.2.24](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.23...rig-mongodb-v0.2.24) - 2025-10-14

### Added

- *(rig-951)* generic HTTP client ([#875](https://github.com/0xPlaygrounds/rig/pull/875))

### Fixed

- trying to fix test regressions part 2 ([#913](https://github.com/0xPlaygrounds/rig/pull/913))
- test regression ([#912](https://github.com/0xPlaygrounds/rig/pull/912))
- *(rig-983)* http request fail due to no content type header set ([#909](https://github.com/0xPlaygrounds/rig/pull/909))

## [0.2.23](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.22...rig-mongodb-v0.2.23) - 2025-09-29

### Other

- updated the following local packages: rig-core

## [0.2.22](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.21...rig-mongodb-v0.2.22) - 2025-09-15

### Other

- updated the following local packages: rig-core

## [0.2.21](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.20...rig-mongodb-v0.2.21) - 2025-09-02

### Other

- *(rig-907)* use where clause for trait bounds ([#749](https://github.com/0xPlaygrounds/rig/pull/749))

## [0.2.20](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.19...rig-mongodb-v0.2.20) - 2025-08-20

### Other

- updated the following local packages: rig-core

## [0.2.19](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.18...rig-mongodb-v0.2.19) - 2025-08-19

### Other

- updated the following local packages: rig-core

## [0.2.18](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.17...rig-mongodb-v0.2.18) - 2025-08-19

### Other

- updated the following local packages: rig-core

## [0.2.17](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.16...rig-mongodb-v0.2.17) - 2025-08-05

### Other

- updated the following local packages: rig-core

## [0.2.16](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.15...rig-mongodb-v0.2.16) - 2025-08-05

### Added

- *(rig-845)* cosine similarity for vector search ([#664](https://github.com/0xPlaygrounds/rig/pull/664))

## [0.2.15](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.14...rig-mongodb-v0.2.15) - 2025-07-30

### Added

- *(rig-819)* vector store index request struct ([#623](https://github.com/0xPlaygrounds/rig/pull/623))
- *(rig-mongodb)* implement InsertDocuments trait ([#596](https://github.com/0xPlaygrounds/rig/pull/596))

### Other

- Refactor clients with builder pattern ([#615](https://github.com/0xPlaygrounds/rig/pull/615))

## [0.2.14](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.13...rig-mongodb-v0.2.14) - 2025-07-16

### Other

- updated the following local packages: rig-core

## [0.2.13](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.12...rig-mongodb-v0.2.13) - 2025-07-14

### Other

- updated the following local packages: rig-core

## [0.2.12](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.11...rig-mongodb-v0.2.12) - 2025-07-07

### Other

- Migrate all crates to Rust 2024 ([#539](https://github.com/0xPlaygrounds/rig/pull/539))
- Declare shared dependencies in workspace ([#538](https://github.com/0xPlaygrounds/rig/pull/538))
- Make clippy happy on all targets ([#542](https://github.com/0xPlaygrounds/rig/pull/542))

## [0.2.11](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.10...rig-mongodb-v0.2.11) - 2025-06-09

### Other

- Introduce Client Traits and Testing ([#440](https://github.com/0xPlaygrounds/rig/pull/440))

## [0.2.10](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.9...rig-mongodb-v0.2.10) - 2025-04-29

### Other

- updated the following local packages: rig-core

## [0.2.9](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.8...rig-mongodb-v0.2.9) - 2025-04-12

### Other

- updated the following local packages: rig-core

## [0.2.8](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.7...rig-mongodb-v0.2.8) - 2025-03-31

### Other

- updated the following local packages: rig-core

## [0.2.7](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.6...rig-mongodb-v0.2.7) - 2025-03-17

### Other

- updated the following local packages: rig-core

## [0.2.6](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.5...rig-mongodb-v0.2.6) - 2025-03-03

### Other

- updated the following local packages: rig-core

## [0.2.5](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.4...rig-mongodb-v0.2.5) - 2025-02-17

### Other

- updated the following local packages: rig-core

## [0.2.4](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.3...rig-mongodb-v0.2.4) - 2025-02-10

### Fixed

- mongodb vector search example

## [0.2.3](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.2...rig-mongodb-v0.2.3) - 2025-01-27

### Other

- update Cargo.lock dependencies

## [0.2.2](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.1...rig-mongodb-v0.2.2) - 2025-01-13

### Other

- Mock provider API in vector store integration tests (#186)

## [0.2.1](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.2.0...rig-mongodb-v0.2.1) - 2024-12-19

### Added

- agent pipelines (#131)

### Other

- *(rig-mongodb)* fix mongodb flaky integration test (#154)
- *(rig-mongodb)* fix flaky test (#153)

## [0.2.0](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.1.5...rig-mongodb-v0.2.0) - 2024-12-03

### Added

- embeddings API overhaul ([#120](https://github.com/0xPlaygrounds/rig/pull/120))

### Fixed

- *(rig-mongodb)* remove embeddings from `top_n` lookup ([#115](https://github.com/0xPlaygrounds/rig/pull/115))

### Other

- *(integration test)* MongoDB ([#126](https://github.com/0xPlaygrounds/rig/pull/126))

## [0.1.5](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.1.4...rig-mongodb-v0.1.5) - 2024-11-13

### Other

- updated the following local packages: rig-core

## [0.1.4](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.1.3...rig-mongodb-v0.1.4) - 2024-11-07

### Added

- Qdrant support

### Fixed

- wrong reference to companion crate
- missing qdrant readme reference

### Other

- update deps version
- add coloured logos for integrations

## [0.1.3](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.1.2...rig-mongodb-v0.1.3) - 2024-10-24

### Fixed

- make PR changes pt I
- mongodb vector search - use num_candidates from search params

### Other

- Merge branch 'main' into feat(vector-store)/lancedb

## [0.1.2](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.1.1...rig-mongodb-v0.1.2) - 2024-10-01

### Other

- updated the following local packages: rig-core

## [0.1.1](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.1.0...rig-mongodb-v0.1.1) - 2024-10-01

### Other

- updated the following local packages: rig-core

## [0.1.0](https://github.com/0xPlaygrounds/rig/compare/rig-mongodb-v0.0.7...rig-mongodb-v0.1.0) - 2024-09-16

### Other

- fmt code
