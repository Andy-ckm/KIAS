# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]
## [0.4.1](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.4.0...rig-fastembed-v0.4.1) - 2026-05-13

### Other

- AGENTS.MD, CONTRIBUTING.MD, and docs ([#1714](https://github.com/0xPlaygrounds/rig/pull/1714)) (by @gold-silver-copper) - #1714
- improve project organization and create rig crate ([#1699](https://github.com/0xPlaygrounds/rig/pull/1699)) (by @gold-silver-copper) - #1699

### Contributors

* @gold-silver-copper
## [0.4.0](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.3.4...rig-fastembed-v0.4.0) - 2026-04-28

### Added

- rustls by default for everything ([#1682](https://github.com/0xPlaygrounds/rig/pull/1682)) (by @gold-silver-copper) - #1682

### Other

- Add clippy no panic lints ([#1663](https://github.com/0xPlaygrounds/rig/pull/1663)) (by @gold-silver-copper) - #1663
- standardize required fields handling across builders ([#1611](https://github.com/0xPlaygrounds/rig/pull/1611)) (by @isSerge) - #1611

### Contributors

* @gold-silver-copper
* @isSerge
## [0.3.4](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.3.3...rig-fastembed-v0.3.4) - 2026-04-12

### Other

- updated the following local packages: rig-core

## [0.3.3](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.3.2...rig-fastembed-v0.3.3) - 2026-03-29

### Other

- updated the following local packages: rig-core

## [0.3.2](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.3.1...rig-fastembed-v0.3.2) - 2026-03-17

### Other

- updated the following local packages: rig-core


## [0.3.1](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.3.0...rig-fastembed-v0.3.1) - 2026-03-05

### Other

- updated the following local packages: rig-core

## [0.2.23](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.22...rig-fastembed-v0.2.23) - 2026-02-17

### Other

- updated the following local packages: rig-core

## [0.2.22](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.21...rig-fastembed-v0.2.22) - 2026-02-03

### Other

- updated the following local packages: rig-core

## [0.2.21](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.20...rig-fastembed-v0.2.21) - 2026-01-20

### Other

- updated the following local packages: rig-core

## [0.2.20](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.19...rig-fastembed-v0.2.20) - 2026-01-06

### Other

- updated the following local packages: rig-core

## [0.2.19](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.18...rig-fastembed-v0.2.19) - 2025-12-15

### Other

- *(rig-1090)* crate re-org ([#1145](https://github.com/0xPlaygrounds/rig/pull/1145))

## [0.2.18](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.17...rig-fastembed-v0.2.18) - 2025-12-04

### Other

- updated the following local packages: rig-core

## [0.2.17](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.16...rig-fastembed-v0.2.17) - 2025-12-01

### Added

- *(rig-985)* Consolidate provider clients ([#1050](https://github.com/0xPlaygrounds/rig/pull/1050))

### Fixed

- *(rig-1050)* Inconsistent model/agent initialisation methods ([#1069](https://github.com/0xPlaygrounds/rig/pull/1069))

## [0.2.16](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.15...rig-fastembed-v0.2.16) - 2025-11-10

### Other

- updated the following local packages: rig-core

## [0.2.15](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.14...rig-fastembed-v0.2.15) - 2025-10-28

### Other

- updated the following local packages: rig-core

## [0.2.14](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.13...rig-fastembed-v0.2.14) - 2025-10-27

### Other

- Dependent packages no longer force unnecessary features on rig-core ([#964](https://github.com/0xPlaygrounds/rig/pull/964))

## [0.2.13](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.12...rig-fastembed-v0.2.13) - 2025-10-14

### Other

- *(rig-984)* rename rig fastembed example filenames ([#914](https://github.com/0xPlaygrounds/rig/pull/914))

## [0.2.12](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.11...rig-fastembed-v0.2.12) - 2025-09-29

### Other

- updated the following local packages: rig-core

## [0.2.11](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.10...rig-fastembed-v0.2.11) - 2025-09-15

### Other

- updated the following local packages: rig-core

## [0.2.10](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.9...rig-fastembed-v0.2.10) - 2025-09-02

### Other

- updated the following local packages: rig-core

## [0.2.9](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.8...rig-fastembed-v0.2.9) - 2025-08-20

### Other

- updated the following local packages: rig-core

## [0.2.8](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.7...rig-fastembed-v0.2.8) - 2025-08-19

### Other

- updated the following local packages: rig-core

## [0.2.7](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.6...rig-fastembed-v0.2.7) - 2025-08-19

### Other

- update Cargo.toml dependencies

## [0.2.6](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.5...rig-fastembed-v0.2.6) - 2025-08-05

### Other

- updated the following local packages: rig-core

## [0.2.5](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.4...rig-fastembed-v0.2.5) - 2025-08-05

### Other

- updated the following local packages: rig-core

## [0.2.4](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.3...rig-fastembed-v0.2.4) - 2025-07-30

### Added

- *(rig-819)* vector store index request struct ([#623](https://github.com/0xPlaygrounds/rig/pull/623))

## [0.2.3](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.2...rig-fastembed-v0.2.3) - 2025-07-16

### Other

- updated the following local packages: rig-core

## [0.2.2](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.1...rig-fastembed-v0.2.2) - 2025-07-14

### Other

- updated the following local packages: rig-core

## [0.2.1](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.2.0...rig-fastembed-v0.2.1) - 2025-07-07

### Other

- Migrate all crates to Rust 2024 ([#539](https://github.com/0xPlaygrounds/rig/pull/539))
- Declare shared dependencies in workspace ([#538](https://github.com/0xPlaygrounds/rig/pull/538))
- Make clippy happy on all targets ([#542](https://github.com/0xPlaygrounds/rig/pull/542))

## [0.2.0](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.1.6...rig-fastembed-v0.2.0) - 2025-06-09

### Added

- *(rig-762)* update fastembed version ([#480](https://github.com/0xPlaygrounds/rig/pull/480))

## [0.1.6](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.1.5...rig-fastembed-v0.1.6) - 2025-04-29

### Other

- updated the following local packages: rig-core

## [0.1.5](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.1.4...rig-fastembed-v0.1.5) - 2025-04-12

### Other

- updated the following local packages: rig-core

## [0.1.4](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.1.3...rig-fastembed-v0.1.4) - 2025-03-31

### Added

- *(rig-fastembed)* support loading model files from custom path ([#337](https://github.com/0xPlaygrounds/rig/pull/337))

## [0.1.3](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.1.2...rig-fastembed-v0.1.3) - 2025-03-17

### Other

- updated the following local packages: rig-core

## [0.1.2](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.1.1...rig-fastembed-v0.1.2) - 2025-03-03

### Other

- updated the following local packages: rig-core

## [0.1.1](https://github.com/0xPlaygrounds/rig/compare/rig-fastembed-v0.1.0...rig-fastembed-v0.1.1) - 2025-02-17

### Other

- release (#257)

## [0.1.0](https://github.com/0xPlaygrounds/rig/releases/tag/rig-fastembed-v0.1.0) - 2025-02-10

### Added

- fastembed integration (#268)

### Fixed

- *(rig-fastembed)* crate info (#294)
